﻿namespace week_3_takehome
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_menuAwal = new System.Windows.Forms.Panel();
            this.label_ucBank = new System.Windows.Forms.Label();
            this.label_Usernsme = new System.Windows.Forms.Label();
            this.btn_RegisDulu = new System.Windows.Forms.Button();
            this.label_Password = new System.Windows.Forms.Label();
            this.btn_login = new System.Windows.Forms.Button();
            this.txt_PassUtama = new System.Windows.Forms.TextBox();
            this.txt_nameUtama = new System.Windows.Forms.TextBox();
            this.Panel_Regis = new System.Windows.Forms.Panel();
            this.btn_buatRegis = new System.Windows.Forms.Button();
            this.txt_passRegis = new System.Windows.Forms.TextBox();
            this.txt_nameRegis = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_balance = new System.Windows.Forms.Panel();
            this.label_uang = new System.Windows.Forms.Label();
            this.btn_Mauwithdraw = new System.Windows.Forms.Button();
            this.btn_Maudeposit = new System.Windows.Forms.Button();
            this.btn_logout = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel_deposit = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_logoutDepo = new System.Windows.Forms.Button();
            this.txt_InputDepo = new System.Windows.Forms.TextBox();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel_Withdraw = new System.Windows.Forms.Panel();
            this.btn_LogOutWithdraw = new System.Windows.Forms.Button();
            this.label_UangWithdraw = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_inputWithdraw = new System.Windows.Forms.TextBox();
            this.btn_Withdraw = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.panel_menuAwal.SuspendLayout();
            this.Panel_Regis.SuspendLayout();
            this.panel_balance.SuspendLayout();
            this.panel_deposit.SuspendLayout();
            this.panel_Withdraw.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_menuAwal
            // 
            this.panel_menuAwal.Controls.Add(this.label_ucBank);
            this.panel_menuAwal.Controls.Add(this.label_Usernsme);
            this.panel_menuAwal.Controls.Add(this.btn_RegisDulu);
            this.panel_menuAwal.Controls.Add(this.label_Password);
            this.panel_menuAwal.Controls.Add(this.btn_login);
            this.panel_menuAwal.Controls.Add(this.txt_PassUtama);
            this.panel_menuAwal.Controls.Add(this.txt_nameUtama);
            this.panel_menuAwal.Location = new System.Drawing.Point(7, 6);
            this.panel_menuAwal.Name = "panel_menuAwal";
            this.panel_menuAwal.Size = new System.Drawing.Size(487, 420);
            this.panel_menuAwal.TabIndex = 9;
            // 
            // label_ucBank
            // 
            this.label_ucBank.AutoSize = true;
            this.label_ucBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ucBank.Location = new System.Drawing.Point(132, 29);
            this.label_ucBank.Name = "label_ucBank";
            this.label_ucBank.Size = new System.Drawing.Size(260, 61);
            this.label_ucBank.TabIndex = 0;
            this.label_ucBank.Text = "UC BANK";
            // 
            // label_Usernsme
            // 
            this.label_Usernsme.AutoSize = true;
            this.label_Usernsme.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Usernsme.Location = new System.Drawing.Point(34, 108);
            this.label_Usernsme.Name = "label_Usernsme";
            this.label_Usernsme.Size = new System.Drawing.Size(166, 33);
            this.label_Usernsme.TabIndex = 2;
            this.label_Usernsme.Text = "Username: ";
            // 
            // btn_RegisDulu
            // 
            this.btn_RegisDulu.Location = new System.Drawing.Point(186, 284);
            this.btn_RegisDulu.Name = "btn_RegisDulu";
            this.btn_RegisDulu.Size = new System.Drawing.Size(138, 55);
            this.btn_RegisDulu.TabIndex = 6;
            this.btn_RegisDulu.Text = "Register";
            this.btn_RegisDulu.UseVisualStyleBackColor = true;
            this.btn_RegisDulu.Click += new System.EventHandler(this.btn_RegisDulu_Click);
            // 
            // label_Password
            // 
            this.label_Password.AutoSize = true;
            this.label_Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Password.Location = new System.Drawing.Point(60, 155);
            this.label_Password.Name = "label_Password";
            this.label_Password.Size = new System.Drawing.Size(151, 33);
            this.label_Password.TabIndex = 1;
            this.label_Password.Text = "Password:";
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(186, 229);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(138, 49);
            this.btn_login.TabIndex = 5;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // txt_PassUtama
            // 
            this.txt_PassUtama.Location = new System.Drawing.Point(229, 159);
            this.txt_PassUtama.Name = "txt_PassUtama";
            this.txt_PassUtama.Size = new System.Drawing.Size(174, 31);
            this.txt_PassUtama.TabIndex = 4;
            // 
            // txt_nameUtama
            // 
            this.txt_nameUtama.Location = new System.Drawing.Point(229, 112);
            this.txt_nameUtama.Name = "txt_nameUtama";
            this.txt_nameUtama.Size = new System.Drawing.Size(174, 31);
            this.txt_nameUtama.TabIndex = 3;
            // 
            // Panel_Regis
            // 
            this.Panel_Regis.Controls.Add(this.btn_buatRegis);
            this.Panel_Regis.Controls.Add(this.txt_passRegis);
            this.Panel_Regis.Controls.Add(this.txt_nameRegis);
            this.Panel_Regis.Controls.Add(this.label3);
            this.Panel_Regis.Controls.Add(this.label2);
            this.Panel_Regis.Controls.Add(this.label1);
            this.Panel_Regis.Location = new System.Drawing.Point(724, 47);
            this.Panel_Regis.Name = "Panel_Regis";
            this.Panel_Regis.Size = new System.Drawing.Size(488, 420);
            this.Panel_Regis.TabIndex = 10;
            // 
            // btn_buatRegis
            // 
            this.btn_buatRegis.Location = new System.Drawing.Point(198, 260);
            this.btn_buatRegis.Name = "btn_buatRegis";
            this.btn_buatRegis.Size = new System.Drawing.Size(138, 55);
            this.btn_buatRegis.TabIndex = 8;
            this.btn_buatRegis.Text = "Register";
            this.btn_buatRegis.UseVisualStyleBackColor = true;
            this.btn_buatRegis.Click += new System.EventHandler(this.btn_buatRegis_Click);
            // 
            // txt_passRegis
            // 
            this.txt_passRegis.Location = new System.Drawing.Point(198, 171);
            this.txt_passRegis.Name = "txt_passRegis";
            this.txt_passRegis.Size = new System.Drawing.Size(174, 31);
            this.txt_passRegis.TabIndex = 8;
            // 
            // txt_nameRegis
            // 
            this.txt_nameRegis.Location = new System.Drawing.Point(198, 112);
            this.txt_nameRegis.Name = "txt_nameRegis";
            this.txt_nameRegis.Size = new System.Drawing.Size(174, 31);
            this.txt_nameRegis.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(52, 167);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 33);
            this.label3.TabIndex = 8;
            this.label3.Text = "Password:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(166, 33);
            this.label2.TabIndex = 8;
            this.label2.Text = "Username: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(133, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(260, 61);
            this.label1.TabIndex = 8;
            this.label1.Text = "UC BANK";
            // 
            // panel_balance
            // 
            this.panel_balance.Controls.Add(this.label_uang);
            this.panel_balance.Controls.Add(this.btn_Mauwithdraw);
            this.panel_balance.Controls.Add(this.btn_Maudeposit);
            this.panel_balance.Controls.Add(this.panel_menuAwal);
            this.panel_balance.Controls.Add(this.btn_logout);
            this.panel_balance.Controls.Add(this.label4);
            this.panel_balance.Location = new System.Drawing.Point(3, 0);
            this.panel_balance.Name = "panel_balance";
            this.panel_balance.Size = new System.Drawing.Size(487, 465);
            this.panel_balance.TabIndex = 11;
            // 
            // label_uang
            // 
            this.label_uang.AutoSize = true;
            this.label_uang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_uang.Location = new System.Drawing.Point(186, 185);
            this.label_uang.Name = "label_uang";
            this.label_uang.Size = new System.Drawing.Size(116, 33);
            this.label_uang.TabIndex = 15;
            this.label_uang.Text = "Rp 0,00";
            // 
            // btn_Mauwithdraw
            // 
            this.btn_Mauwithdraw.Location = new System.Drawing.Point(192, 325);
            this.btn_Mauwithdraw.Name = "btn_Mauwithdraw";
            this.btn_Mauwithdraw.Size = new System.Drawing.Size(119, 57);
            this.btn_Mauwithdraw.TabIndex = 13;
            this.btn_Mauwithdraw.Text = "withdraw";
            this.btn_Mauwithdraw.UseVisualStyleBackColor = true;
            this.btn_Mauwithdraw.Click += new System.EventHandler(this.btn_Mauwithdraw_Click);
            // 
            // btn_Maudeposit
            // 
            this.btn_Maudeposit.Location = new System.Drawing.Point(192, 251);
            this.btn_Maudeposit.Name = "btn_Maudeposit";
            this.btn_Maudeposit.Size = new System.Drawing.Size(119, 54);
            this.btn_Maudeposit.TabIndex = 12;
            this.btn_Maudeposit.Text = "deposit";
            this.btn_Maudeposit.UseVisualStyleBackColor = true;
            this.btn_Maudeposit.Click += new System.EventHandler(this.btn_Maudeposit_Click);
            // 
            // btn_logout
            // 
            this.btn_logout.Location = new System.Drawing.Point(335, 124);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(112, 52);
            this.btn_logout.TabIndex = 11;
            this.btn_logout.Text = "log out";
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(132, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(260, 61);
            this.label4.TabIndex = 10;
            this.label4.Text = "UC BANK";
            // 
            // panel_deposit
            // 
            this.panel_deposit.Controls.Add(this.label7);
            this.panel_deposit.Controls.Add(this.btn_logoutDepo);
            this.panel_deposit.Controls.Add(this.txt_InputDepo);
            this.panel_deposit.Controls.Add(this.btn_deposit);
            this.panel_deposit.Controls.Add(this.label6);
            this.panel_deposit.Location = new System.Drawing.Point(724, 50);
            this.panel_deposit.Name = "panel_deposit";
            this.panel_deposit.Size = new System.Drawing.Size(497, 465);
            this.panel_deposit.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(108, 259);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(294, 33);
            this.label7.TabIndex = 13;
            this.label7.Text = "Input Deposit Emount";
            // 
            // btn_logoutDepo
            // 
            this.btn_logoutDepo.Location = new System.Drawing.Point(346, 124);
            this.btn_logoutDepo.Name = "btn_logoutDepo";
            this.btn_logoutDepo.Size = new System.Drawing.Size(112, 52);
            this.btn_logoutDepo.TabIndex = 12;
            this.btn_logoutDepo.Text = "log out";
            this.btn_logoutDepo.UseVisualStyleBackColor = true;
            this.btn_logoutDepo.Click += new System.EventHandler(this.btn_logoutDepo_Click);
            // 
            // txt_InputDepo
            // 
            this.txt_InputDepo.Location = new System.Drawing.Point(145, 309);
            this.txt_InputDepo.Name = "txt_InputDepo";
            this.txt_InputDepo.Size = new System.Drawing.Size(200, 31);
            this.txt_InputDepo.TabIndex = 12;
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(181, 354);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(117, 50);
            this.btn_deposit.TabIndex = 11;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(121, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(260, 61);
            this.label6.TabIndex = 10;
            this.label6.Text = "UC BANK";
            // 
            // panel_Withdraw
            // 
            this.panel_Withdraw.Controls.Add(this.btn_LogOutWithdraw);
            this.panel_Withdraw.Controls.Add(this.label_UangWithdraw);
            this.panel_Withdraw.Controls.Add(this.panel_balance);
            this.panel_Withdraw.Controls.Add(this.label9);
            this.panel_Withdraw.Controls.Add(this.txt_inputWithdraw);
            this.panel_Withdraw.Controls.Add(this.btn_Withdraw);
            this.panel_Withdraw.Controls.Add(this.label8);
            this.panel_Withdraw.Location = new System.Drawing.Point(724, 47);
            this.panel_Withdraw.Name = "panel_Withdraw";
            this.panel_Withdraw.Size = new System.Drawing.Size(512, 476);
            this.panel_Withdraw.TabIndex = 13;
            // 
            // btn_LogOutWithdraw
            // 
            this.btn_LogOutWithdraw.Location = new System.Drawing.Point(361, 127);
            this.btn_LogOutWithdraw.Name = "btn_LogOutWithdraw";
            this.btn_LogOutWithdraw.Size = new System.Drawing.Size(101, 39);
            this.btn_LogOutWithdraw.TabIndex = 20;
            this.btn_LogOutWithdraw.Text = "Log Out";
            this.btn_LogOutWithdraw.UseVisualStyleBackColor = true;
            // 
            // label_UangWithdraw
            // 
            this.label_UangWithdraw.AutoSize = true;
            this.label_UangWithdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_UangWithdraw.Location = new System.Drawing.Point(185, 192);
            this.label_UangWithdraw.Name = "label_UangWithdraw";
            this.label_UangWithdraw.Size = new System.Drawing.Size(116, 33);
            this.label_UangWithdraw.TabIndex = 19;
            this.label_UangWithdraw.Text = "Rp 0,00";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(89, 268);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(316, 33);
            this.label9.TabIndex = 17;
            this.label9.Text = "Input Withdraw Emount";
            // 
            // txt_inputWithdraw
            // 
            this.txt_inputWithdraw.Location = new System.Drawing.Point(131, 322);
            this.txt_inputWithdraw.Name = "txt_inputWithdraw";
            this.txt_inputWithdraw.Size = new System.Drawing.Size(249, 31);
            this.txt_inputWithdraw.TabIndex = 16;
            // 
            // btn_Withdraw
            // 
            this.btn_Withdraw.Location = new System.Drawing.Point(180, 372);
            this.btn_Withdraw.Name = "btn_Withdraw";
            this.btn_Withdraw.Size = new System.Drawing.Size(160, 48);
            this.btn_Withdraw.TabIndex = 15;
            this.btn_Withdraw.Text = "Withdraw";
            this.btn_Withdraw.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(99, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(260, 61);
            this.label8.TabIndex = 14;
            this.label8.Text = "UC BANK";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1967, 1179);
            this.Controls.Add(this.panel_Withdraw);
            this.Controls.Add(this.panel_deposit);
            this.Controls.Add(this.Panel_Regis);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_menuAwal.ResumeLayout(false);
            this.panel_menuAwal.PerformLayout();
            this.Panel_Regis.ResumeLayout(false);
            this.Panel_Regis.PerformLayout();
            this.panel_balance.ResumeLayout(false);
            this.panel_balance.PerformLayout();
            this.panel_deposit.ResumeLayout(false);
            this.panel_deposit.PerformLayout();
            this.panel_Withdraw.ResumeLayout(false);
            this.panel_Withdraw.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_menuAwal;
        private System.Windows.Forms.Label label_ucBank;
        private System.Windows.Forms.Label label_Usernsme;
        private System.Windows.Forms.Button btn_RegisDulu;
        private System.Windows.Forms.Label label_Password;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.TextBox txt_PassUtama;
        private System.Windows.Forms.TextBox txt_nameUtama;
        private System.Windows.Forms.Panel Panel_Regis;
        private System.Windows.Forms.Button btn_buatRegis;
        private System.Windows.Forms.TextBox txt_passRegis;
        private System.Windows.Forms.TextBox txt_nameRegis;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_balance;
        private System.Windows.Forms.Label label_uang;
        private System.Windows.Forms.Button btn_Mauwithdraw;
        private System.Windows.Forms.Button btn_Maudeposit;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel_deposit;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_logoutDepo;
        private System.Windows.Forms.TextBox txt_InputDepo;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel_Withdraw;
        private System.Windows.Forms.TextBox txt_inputWithdraw;
        private System.Windows.Forms.Button btn_Withdraw;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_LogOutWithdraw;
        private System.Windows.Forms.Label label_UangWithdraw;
    }
}

