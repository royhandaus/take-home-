﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_3_takehome
{
    public partial class Form1 : Form
    {
        private List<string> usernames = new List<string>();
        private decimal balance = 0;

        public Form1()
        {
            InitializeComponent();
            Panel_Regis.Visible = false;
            panel_balance.Visible = false;
            panel_deposit.Visible = false;
            panel_Withdraw.Visible = false;
            btn_Withdraw.Click += btn_Withdraw_Click;
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string username = txt_nameUtama.Text;
            string password = txt_PassUtama.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Username dan password harus diisi!");
            }
            else
            {
                if (usernames.Contains(username))
                {
                    MessageBox.Show("Login berhasil!");
                    panel_balance.Visible = true;
                    panel_menuAwal.Visible = false;
                    label_uang.Text = "Balance: $" + balance.ToString();
                    label_UangWithdraw.Text = "Balance: $" + balance.ToString();
                }
                else
                {
                    MessageBox.Show("Akun tidak ditemukan. Silakan register terlebih dahulu.");
                }
            }

        }

        private void btn_RegisDulu_Click(object sender, EventArgs e)
        {
            panel_menuAwal.Visible = false;
            Panel_Regis.Visible = true;
        }

        private void btn_buatRegis_Click(object sender, EventArgs e)
        {
            string newUsername = txt_nameRegis.Text;
            string newPassword = txt_passRegis.Text;

            if (string.IsNullOrWhiteSpace(newUsername) || string.IsNullOrWhiteSpace(newPassword))
            {
                MessageBox.Show("Username dan password harus diisi!");
            }
            else
            {
                if (!usernames.Contains(newUsername))
                {
                    usernames.Add(newUsername);
                    MessageBox.Show("Registrasi berhasil!");
                    Panel_Regis.Visible = false;
                    panel_menuAwal.Visible = true;
                }
                else
                {
                    MessageBox.Show("Username sudah digunakan. Silakan pilih username lain.");
                }
            }

        }

        private void btn_Maudeposit_Click(object sender, EventArgs e)
        {
            panel_menuAwal.Visible = false;
            panel_deposit.Visible = true;
              
        }
        private void btn_logout_Click(object sender, EventArgs e)
        {
            panel_balance.Visible = false;
            panel_deposit.Visible = false;
            panel_Withdraw.Visible = false;
            panel_menuAwal.Visible = true;
            txt_nameUtama.Text = "";
            txt_PassUtama.Text = "";
            txt_nameRegis.Text = "";
            txt_passRegis.Text = "";
            txt_inputWithdraw.Text = "";
            txt_InputDepo.Text = "";
        }
        private void btn_Mauwithdraw_Click(object sender, EventArgs e)
        {
            panel_menuAwal.Visible = false;
            panel_Withdraw.Visible = true;  
        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
            if (!decimal.TryParse(txt_InputDepo.Text, out decimal depositAmount))
            {
                MessageBox.Show("Silakan masukkan jumlah deposit yang valid.");
            }
            else
            {
                if (depositAmount > 0)
                {
                    balance += depositAmount; 
                    MessageBox.Show("Deposit sebesar" + depositAmount + "berhasil. Balance sekarang: " + balance );
                    label_uang.Text = "Balance: $" + balance.ToString(); 
                    label_UangWithdraw.Text = "Balance: $" + balance.ToString();
                }
                else
                {
                    MessageBox.Show("Jumlah deposit harus lebih dari 0.");
                }
            }

        }

        private void btn_logoutDepo_Click(object sender, EventArgs e)
        {
            panel_balance.Visible = false;
            panel_deposit.Visible = false;
            panel_Withdraw.Visible = false;
            panel_menuAwal.Visible = true;
            txt_nameUtama.Text = "";
            txt_PassUtama.Text = "";
            txt_nameRegis.Text = "";
            txt_passRegis.Text = "";
            txt_inputWithdraw.Text = "";
            txt_InputDepo.Text = "";
        }

        private void btn_logOutWithdraw_Click(object sender, EventArgs e)
        {
            panel_balance.Visible = false;
            panel_deposit.Visible = false;
            panel_Withdraw.Visible = false;
            panel_menuAwal.Visible = true;
            txt_nameUtama.Text = "";
            txt_PassUtama.Text = "";
            txt_nameRegis.Text = "";
            txt_passRegis.Text = "";
            txt_inputWithdraw.Text = "";
            txt_InputDepo.Text = "";
        }

        private void btn_Withdraw_Click(object sender, EventArgs e)
        {
            if (!decimal.TryParse(txt_inputWithdraw.Text, out decimal withdrawAmount))
            {
                MessageBox.Show("Silakan masukkan jumlah withdraw yang valid.");
            }
            else
            {
                if (withdrawAmount > 0)
                {
                    if (withdrawAmount <= balance)
                    {
                        balance -= withdrawAmount; 
                        MessageBox.Show("Withdraw sebesar" + withdrawAmount + "berhasil. Balance sekarang: " + balance );
                        label_uang.Text = "Balance: $" + balance.ToString();
                        label_UangWithdraw.Text = "Balance: $" + balance.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Saldo tidak mencukupi untuk melakukan withdraw.");
                    }
                }
                else
                {
                    MessageBox.Show("Jumlah withdraw harus lebih dari 0.");
                }
            }

        }
    }
}
