﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inventory_blink_shop_3
{
    public partial class Form1 : Form
    {
        DataTable dtProdukSimpan;
        DataTable dtProduktampil;
        DataTable dtCategory;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cBox_filter.Enabled = false;

            dtProduktampil = new DataTable();
            dtProduktampil = dtProdukSimpan;

            dtProdukSimpan = new DataTable();
            dtProdukSimpan.Columns.Add("Id Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stok");
            dtProdukSimpan.Columns.Add("Id Category");
            dtProdukSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProdukSimpan.Rows.Add("J002", "T-Shirt Obsessive", "75000", "16", "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");
            DGV_Product.DataSource = dtProdukSimpan;



            dtCategory = new DataTable();
            dtCategory.Columns.Add("Id Category");
            dtCategory.Columns.Add("Nama Category");
            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");
            DGV_Category.DataSource = dtCategory;


            cBox_filter.Items.Add("C1");
            cBox_filter.Items.Add("C2");
            cBox_filter.Items.Add("C3");
            cBox_filter.Items.Add("C4");
            cBox_filter.Items.Add("C5");

            Cbox_Category.Items.Add("C1");
            Cbox_Category.Items.Add("C2");
            Cbox_Category.Items.Add("C3");
            Cbox_Category.Items.Add("C4");
            Cbox_Category.Items.Add("C5");
        }

        private void btn_AddProduct_Click(object sender, EventArgs e)
        {
            string namaProduk = txt_NamaProduct.Text;
            decimal harga = 0;
            int stok = 0;
            int IdCategory = Convert.ToInt32(Cbox_Category.SelectedValue);

            if (decimal.TryParse(txt_Harga.Text, out harga) && int.TryParse(txt_Stok.Text, out stok))
            {
                string productId = GenerateProductID(namaProduk);
                dtProdukSimpan.Rows.Add(productId, namaProduk, harga, stok, IdCategory);

            }
            else
            {
                MessageBox.Show("Harga dan Stock harus angka.", "error kang/neng", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private string GenerateProductID(string namaProduk)
        {
            string charpertama = namaProduk.Substring(0, 1).ToUpper();
            int count = dtProdukSimpan.Select($"[Nama Product] LIKE '{charpertama}%'").Length + 1;
            string productId = $"{charpertama}{count:D3}";

            return productId;
        }

        private void btn_All_Click(object sender, EventArgs e)
        {
            cBox_filter.Enabled = false;
            DGV_Product.DataSource = dtProduktampil;
            cBox_filter.SelectedItem = null;
            DisplayAllProducts();
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            cBox_filter.Enabled = true;
            DGV_Product.DataSource = dtProduktampil;
        }
        private void DisplayAllProducts()
        {
            DGV_Product.Rows.Clear();
            foreach (DataRow row in dtProdukSimpan.Rows)
            {
                DGV_Product.Rows.Add(row.ItemArray);
            }
        }

        private void btn_EdirProduct_Click(object sender, EventArgs e)
        {

            if (DGV_Product.SelectedRows.Count > 0)
            {
                int rowIndex = DGV_Product.SelectedRows[0].Index;
                string idProduct = DGV_Product.Rows[rowIndex].Cells["Id Product"].Value.ToString();
                string namaProduct = txt_NamaProduct.Text;
                decimal harga = Convert.ToDecimal(txt_Harga.Text);
                int stok = Convert.ToInt32(txt_Stok.Text);
                string idCategory = Cbox_Category.SelectedValue.ToString();

                UpdateProduct(rowIndex, idProduct, namaProduct, harga, stok, idCategory);
            }
            else
            {
                MessageBox.Show("Pilih produk yang akan diubah.", "error Kang/Neng", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void UpdateProduct(int rowIndex, string idProduct, string namaProduct, decimal harga, int stok, string idCategory)
        {

            dtProdukSimpan.Rows[rowIndex]["Nama Product"] = namaProduct;
            dtProdukSimpan.Rows[rowIndex]["Harga"] = harga;
            dtProdukSimpan.Rows[rowIndex]["Stok"] = stok;
            dtProdukSimpan.Rows[rowIndex]["Id Category"] = idCategory;


            DGV_Product.Rows[rowIndex].Cells["Nama Product"].Value = namaProduct;
            DGV_Product.Rows[rowIndex].Cells["Harga"].Value = harga;
            DGV_Product.Rows[rowIndex].Cells["Stok"].Value = stok;
            DGV_Product.Rows[rowIndex].Cells["Id Category"].Value = idCategory;
        }

        private void btn_RemoveProduct_Click(object sender, EventArgs e)
        {
            if (DGV_Product.SelectedRows.Count > 0)
            {
                int rowIndex = DGV_Product.SelectedRows[0].Index;
                RemoveProduct(rowIndex);
            }

        }
        private void RemoveProduct(int rowIndex)
        {
            dtProdukSimpan.Rows.RemoveAt(rowIndex);
            DGV_Product.Rows.RemoveAt(rowIndex);
        }

        private void btn_AddCategory_Click(object sender, EventArgs e)
        {
            string namaCategory = txt_NamaCategory.Text;
            if (!string.IsNullOrEmpty(namaCategory))
            {
                string idCategory = GenerateCategoryId();
                dtCategory.Rows.Add(idCategory, namaCategory);
            }
            else
            {
                MessageBox.Show("Nama kategori tidak boleh kosong.", "error Kang/Neng", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private string GenerateCategoryId()
        {
            int existingCategoryCount = dtCategory.Rows.Count;
            int newCategoryId = existingCategoryCount + 1;
            return "C" + newCategoryId.ToString();
        }

        private void btn_RemoveCategory_Click(object sender, EventArgs e)
        {
            {
                
                string IDC = bantuan();
                Cbox_Category.Items.Remove(IDC);

                int x = 0;
                for (int i = dtProdukSimpan.Rows.Count - 1; i >= 0; i--)
                {
                    if (dtProdukSimpan.Rows[i][4].ToString() == IDC)
                    {
                        dtProdukSimpan.Rows.RemoveAt(i);
                        x++;
                    }
                    else if (Cbox_Category.Text == "")
                    {
                        MessageBox.Show("blm diisi", "error Kang/Neng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        x++;
                        break;
                    }
                }
                dtProduktampil = dtProdukSimpan;
                
                for (int i = dtCategory.Rows.Count - 1; i >= 0; i--)
                {
                    if (dtCategory.Rows[i][1].ToString() == txt_NamaCategory.Text)
                    {
                        dtCategory.Rows.RemoveAt(i);
                        x++;
                    }
                }
                if (x == 0)
                {
                    MessageBox.Show("Category tidak ditemukan", "error Kang/Neng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txt_NamaCategory.Clear();
                }
                txt_NamaCategory.Clear();
            }
        }
        private string bantuan()
        {
            string IDC = "";
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i][1].ToString() == txt_NamaCategory.Text)
                {
                    IDC = dtCategory.Rows[i][0].ToString();
                    break;
                }
            }
            return IDC;
        }

        private void DGV_Product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow SelectedRow = DGV_Product.Rows[e.RowIndex];
            txt_NamaProduct.Text = SelectedRow.Cells["Nama Product"].Value.ToString();
            txt_Harga.Text = SelectedRow.Cells["Harga"].Value.ToString();
            txt_Stok.Text = SelectedRow.Cells["Stok"].Value.ToString();
            Cbox_Category.SelectedValue = SelectedRow.Cells["Id Category"].Value.ToString();
        }

        private void DGV_Category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow SelectedRow = DGV_Category.Rows[e.RowIndex];
            txt_NamaCategory.Text = SelectedRow.Cells["Nama Category"].Value.ToString();
        }

        private void txt_Harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                //MessageBox.Show("Hanya angka yang diperbolehkan!", "error Kang/Neng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Handled = true;
            }
        }

        private void txt_Stok_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                //MessageBox.Show("Hanya angka yang diperbolehkan!", "error Kang/Neng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Handled = true;
            }
        }

        private void cBox_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string filter = cBox_filter.SelectedItem.ToString();
            DataTable filteredTable = dtProdukSimpan.Clone();

            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (dtProdukSimpan.Rows[i][4].ToString() == filter)
                {
                    DataRow simpen = filteredTable.NewRow();
                    simpen.ItemArray = dtProdukSimpan.Rows[i].ItemArray;
                    filteredTable.Rows.Add(simpen);
                }
            }
            DGV_Product.DataSource = filteredTable;
        }
    }
}
