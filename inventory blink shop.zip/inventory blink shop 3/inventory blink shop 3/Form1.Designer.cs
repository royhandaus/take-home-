﻿namespace inventory_blink_shop_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DGV_Product = new System.Windows.Forms.DataGridView();
            this.DGV_Category = new System.Windows.Forms.DataGridView();
            this.btn_AddCategory = new System.Windows.Forms.Button();
            this.btn_RemoveCategory = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.btn_All = new System.Windows.Forms.Button();
            this.btn_EdirProduct = new System.Windows.Forms.Button();
            this.btn_RemoveProduct = new System.Windows.Forms.Button();
            this.btn_AddProduct = new System.Windows.Forms.Button();
            this.txt_NamaProduct = new System.Windows.Forms.TextBox();
            this.txt_Harga = new System.Windows.Forms.TextBox();
            this.txt_Stok = new System.Windows.Forms.TextBox();
            this.txt_NamaCategory = new System.Windows.Forms.TextBox();
            this.cBox_filter = new System.Windows.Forms.ComboBox();
            this.Cbox_Category = new System.Windows.Forms.ComboBox();
            this.lb_stok = new System.Windows.Forms.Label();
            this.lb_Harga = new System.Windows.Forms.Label();
            this.lb_comboCategory = new System.Windows.Forms.Label();
            this.lb_NamaProduct = new System.Windows.Forms.Label();
            this.lb_Detail = new System.Windows.Forms.Label();
            this.lb_NamaCategory = new System.Windows.Forms.Label();
            this.lb_Category = new System.Windows.Forms.Label();
            this.lb_Product = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Category)).BeginInit();
            this.SuspendLayout();
            // 
            // DGV_Product
            // 
            this.DGV_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Product.Location = new System.Drawing.Point(45, 152);
            this.DGV_Product.Name = "DGV_Product";
            this.DGV_Product.RowHeadersWidth = 82;
            this.DGV_Product.RowTemplate.Height = 33;
            this.DGV_Product.Size = new System.Drawing.Size(1072, 602);
            this.DGV_Product.TabIndex = 0;
            this.DGV_Product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_Product_CellClick);
            // 
            // DGV_Category
            // 
            this.DGV_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Category.Location = new System.Drawing.Point(1322, 162);
            this.DGV_Category.Name = "DGV_Category";
            this.DGV_Category.RowHeadersWidth = 82;
            this.DGV_Category.RowTemplate.Height = 33;
            this.DGV_Category.Size = new System.Drawing.Size(486, 602);
            this.DGV_Category.TabIndex = 1;
            this.DGV_Category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_Category_CellClick);
            // 
            // btn_AddCategory
            // 
            this.btn_AddCategory.BackColor = System.Drawing.Color.Lime;
            this.btn_AddCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddCategory.Location = new System.Drawing.Point(1403, 925);
            this.btn_AddCategory.Name = "btn_AddCategory";
            this.btn_AddCategory.Size = new System.Drawing.Size(152, 130);
            this.btn_AddCategory.TabIndex = 2;
            this.btn_AddCategory.Text = "Add Category";
            this.btn_AddCategory.UseVisualStyleBackColor = false;
            this.btn_AddCategory.Click += new System.EventHandler(this.btn_AddCategory_Click);
            // 
            // btn_RemoveCategory
            // 
            this.btn_RemoveCategory.BackColor = System.Drawing.Color.Red;
            this.btn_RemoveCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_RemoveCategory.Location = new System.Drawing.Point(1577, 925);
            this.btn_RemoveCategory.Name = "btn_RemoveCategory";
            this.btn_RemoveCategory.Size = new System.Drawing.Size(152, 130);
            this.btn_RemoveCategory.TabIndex = 3;
            this.btn_RemoveCategory.Text = "Remove Category";
            this.btn_RemoveCategory.UseVisualStyleBackColor = false;
            this.btn_RemoveCategory.Click += new System.EventHandler(this.btn_RemoveCategory_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(751, 92);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(119, 50);
            this.btn_filter.TabIndex = 4;
            this.btn_filter.Text = "Filter";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // btn_All
            // 
            this.btn_All.Location = new System.Drawing.Point(603, 92);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(112, 54);
            this.btn_All.TabIndex = 5;
            this.btn_All.Text = "All";
            this.btn_All.UseVisualStyleBackColor = true;
            this.btn_All.Click += new System.EventHandler(this.btn_All_Click);
            // 
            // btn_EdirProduct
            // 
            this.btn_EdirProduct.BackColor = System.Drawing.Color.Yellow;
            this.btn_EdirProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EdirProduct.Location = new System.Drawing.Point(763, 950);
            this.btn_EdirProduct.Name = "btn_EdirProduct";
            this.btn_EdirProduct.Size = new System.Drawing.Size(166, 151);
            this.btn_EdirProduct.TabIndex = 6;
            this.btn_EdirProduct.Text = "Edit Product";
            this.btn_EdirProduct.UseVisualStyleBackColor = false;
            this.btn_EdirProduct.Click += new System.EventHandler(this.btn_EdirProduct_Click);
            // 
            // btn_RemoveProduct
            // 
            this.btn_RemoveProduct.BackColor = System.Drawing.Color.Red;
            this.btn_RemoveProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_RemoveProduct.Location = new System.Drawing.Point(957, 950);
            this.btn_RemoveProduct.Name = "btn_RemoveProduct";
            this.btn_RemoveProduct.Size = new System.Drawing.Size(171, 151);
            this.btn_RemoveProduct.TabIndex = 7;
            this.btn_RemoveProduct.Text = "Remove Product";
            this.btn_RemoveProduct.UseVisualStyleBackColor = false;
            this.btn_RemoveProduct.Click += new System.EventHandler(this.btn_RemoveProduct_Click);
            // 
            // btn_AddProduct
            // 
            this.btn_AddProduct.BackColor = System.Drawing.Color.Lime;
            this.btn_AddProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddProduct.Location = new System.Drawing.Point(563, 950);
            this.btn_AddProduct.Name = "btn_AddProduct";
            this.btn_AddProduct.Size = new System.Drawing.Size(177, 151);
            this.btn_AddProduct.TabIndex = 8;
            this.btn_AddProduct.Text = "Add Product";
            this.btn_AddProduct.UseVisualStyleBackColor = false;
            this.btn_AddProduct.Click += new System.EventHandler(this.btn_AddProduct_Click);
            // 
            // txt_NamaProduct
            // 
            this.txt_NamaProduct.Location = new System.Drawing.Point(308, 842);
            this.txt_NamaProduct.Name = "txt_NamaProduct";
            this.txt_NamaProduct.Size = new System.Drawing.Size(315, 31);
            this.txt_NamaProduct.TabIndex = 9;
            // 
            // txt_Harga
            // 
            this.txt_Harga.Location = new System.Drawing.Point(308, 960);
            this.txt_Harga.Name = "txt_Harga";
            this.txt_Harga.Size = new System.Drawing.Size(190, 31);
            this.txt_Harga.TabIndex = 10;
            this.txt_Harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Harga_KeyPress);
            // 
            // txt_Stok
            // 
            this.txt_Stok.Location = new System.Drawing.Point(308, 1023);
            this.txt_Stok.Name = "txt_Stok";
            this.txt_Stok.Size = new System.Drawing.Size(190, 31);
            this.txt_Stok.TabIndex = 11;
            this.txt_Stok.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Stok_KeyPress);
            // 
            // txt_NamaCategory
            // 
            this.txt_NamaCategory.Location = new System.Drawing.Point(1509, 859);
            this.txt_NamaCategory.Name = "txt_NamaCategory";
            this.txt_NamaCategory.Size = new System.Drawing.Size(220, 31);
            this.txt_NamaCategory.TabIndex = 12;
            // 
            // cBox_filter
            // 
            this.cBox_filter.FormattingEnabled = true;
            this.cBox_filter.Location = new System.Drawing.Point(915, 92);
            this.cBox_filter.Name = "cBox_filter";
            this.cBox_filter.Size = new System.Drawing.Size(183, 33);
            this.cBox_filter.TabIndex = 13;
            this.cBox_filter.SelectedIndexChanged += new System.EventHandler(this.cBox_filter_SelectedIndexChanged);
            // 
            // Cbox_Category
            // 
            this.Cbox_Category.FormattingEnabled = true;
            this.Cbox_Category.Location = new System.Drawing.Point(308, 901);
            this.Cbox_Category.Name = "Cbox_Category";
            this.Cbox_Category.Size = new System.Drawing.Size(190, 33);
            this.Cbox_Category.TabIndex = 14;
            // 
            // lb_stok
            // 
            this.lb_stok.AutoSize = true;
            this.lb_stok.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_stok.Location = new System.Drawing.Point(176, 1026);
            this.lb_stok.Name = "lb_stok";
            this.lb_stok.Size = new System.Drawing.Size(73, 29);
            this.lb_stok.TabIndex = 37;
            this.lb_stok.Text = "Stock";
            // 
            // lb_Harga
            // 
            this.lb_Harga.AutoSize = true;
            this.lb_Harga.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Harga.Location = new System.Drawing.Point(176, 962);
            this.lb_Harga.Name = "lb_Harga";
            this.lb_Harga.Size = new System.Drawing.Size(78, 29);
            this.lb_Harga.TabIndex = 36;
            this.lb_Harga.Text = "Harga";
            // 
            // lb_comboCategory
            // 
            this.lb_comboCategory.AutoSize = true;
            this.lb_comboCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_comboCategory.Location = new System.Drawing.Point(149, 901);
            this.lb_comboCategory.Name = "lb_comboCategory";
            this.lb_comboCategory.Size = new System.Drawing.Size(110, 29);
            this.lb_comboCategory.TabIndex = 35;
            this.lb_comboCategory.Text = "Category";
            // 
            // lb_NamaProduct
            // 
            this.lb_NamaProduct.AutoSize = true;
            this.lb_NamaProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_NamaProduct.Location = new System.Drawing.Point(176, 842);
            this.lb_NamaProduct.Name = "lb_NamaProduct";
            this.lb_NamaProduct.Size = new System.Drawing.Size(83, 29);
            this.lb_NamaProduct.TabIndex = 34;
            this.lb_NamaProduct.Text = "Nama:";
            // 
            // lb_Detail
            // 
            this.lb_Detail.AutoSize = true;
            this.lb_Detail.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Detail.Location = new System.Drawing.Point(50, 773);
            this.lb_Detail.Name = "lb_Detail";
            this.lb_Detail.Size = new System.Drawing.Size(113, 42);
            this.lb_Detail.TabIndex = 33;
            this.lb_Detail.Text = "Detail";
            // 
            // lb_NamaCategory
            // 
            this.lb_NamaCategory.AutoSize = true;
            this.lb_NamaCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_NamaCategory.Location = new System.Drawing.Point(1368, 859);
            this.lb_NamaCategory.Name = "lb_NamaCategory";
            this.lb_NamaCategory.Size = new System.Drawing.Size(83, 29);
            this.lb_NamaCategory.TabIndex = 38;
            this.lb_NamaCategory.Text = "Nama:";
            // 
            // lb_Category
            // 
            this.lb_Category.AutoSize = true;
            this.lb_Category.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Category.Location = new System.Drawing.Point(1315, 92);
            this.lb_Category.Name = "lb_Category";
            this.lb_Category.Size = new System.Drawing.Size(170, 42);
            this.lb_Category.TabIndex = 39;
            this.lb_Category.Text = "Category";
            // 
            // lb_Product
            // 
            this.lb_Product.AutoSize = true;
            this.lb_Product.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Product.Location = new System.Drawing.Point(50, 80);
            this.lb_Product.Name = "lb_Product";
            this.lb_Product.Size = new System.Drawing.Size(147, 42);
            this.lb_Product.TabIndex = 40;
            this.lb_Product.Text = "Product";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(1947, 1159);
            this.Controls.Add(this.lb_Product);
            this.Controls.Add(this.lb_Category);
            this.Controls.Add(this.lb_NamaCategory);
            this.Controls.Add(this.lb_stok);
            this.Controls.Add(this.lb_Harga);
            this.Controls.Add(this.lb_comboCategory);
            this.Controls.Add(this.lb_NamaProduct);
            this.Controls.Add(this.lb_Detail);
            this.Controls.Add(this.Cbox_Category);
            this.Controls.Add(this.cBox_filter);
            this.Controls.Add(this.txt_NamaCategory);
            this.Controls.Add(this.txt_Stok);
            this.Controls.Add(this.txt_Harga);
            this.Controls.Add(this.txt_NamaProduct);
            this.Controls.Add(this.btn_AddProduct);
            this.Controls.Add(this.btn_RemoveProduct);
            this.Controls.Add(this.btn_EdirProduct);
            this.Controls.Add(this.btn_All);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_RemoveCategory);
            this.Controls.Add(this.btn_AddCategory);
            this.Controls.Add(this.DGV_Category);
            this.Controls.Add(this.DGV_Product);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGV_Product;
        private System.Windows.Forms.DataGridView DGV_Category;
        private System.Windows.Forms.Button btn_AddCategory;
        private System.Windows.Forms.Button btn_RemoveCategory;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.Button btn_All;
        private System.Windows.Forms.Button btn_EdirProduct;
        private System.Windows.Forms.Button btn_RemoveProduct;
        private System.Windows.Forms.Button btn_AddProduct;
        private System.Windows.Forms.TextBox txt_NamaProduct;
        private System.Windows.Forms.TextBox txt_Harga;
        private System.Windows.Forms.TextBox txt_Stok;
        private System.Windows.Forms.TextBox txt_NamaCategory;
        private System.Windows.Forms.ComboBox cBox_filter;
        private System.Windows.Forms.ComboBox Cbox_Category;
        private System.Windows.Forms.Label lb_stok;
        private System.Windows.Forms.Label lb_Harga;
        private System.Windows.Forms.Label lb_comboCategory;
        private System.Windows.Forms.Label lb_NamaProduct;
        private System.Windows.Forms.Label lb_Detail;
        private System.Windows.Forms.Label lb_NamaCategory;
        private System.Windows.Forms.Label lb_Category;
        private System.Windows.Forms.Label lb_Product;
    }
}

