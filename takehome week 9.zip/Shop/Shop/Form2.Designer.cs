﻿namespace Shop
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DGV_Others = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_total = new System.Windows.Forms.TextBox();
            this.txt_SubTotal = new System.Windows.Forms.TextBox();
            this.btn_Add4 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_ItemPrice = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_ItemName = new System.Windows.Forms.TextBox();
            this.btn_Upload = new System.Windows.Forms.Button();
            this.Pbox_Other = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Others)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pbox_Other)).BeginInit();
            this.SuspendLayout();
            // 
            // DGV_Others
            // 
            this.DGV_Others.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Others.Location = new System.Drawing.Point(813, 72);
            this.DGV_Others.Name = "DGV_Others";
            this.DGV_Others.RowHeadersWidth = 82;
            this.DGV_Others.RowTemplate.Height = 33;
            this.DGV_Others.Size = new System.Drawing.Size(885, 744);
            this.DGV_Others.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(913, 1009);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 37);
            this.label8.TabIndex = 18;
            this.label8.Text = "Total";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(862, 916);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(156, 37);
            this.label7.TabIndex = 17;
            this.label7.Text = "Sub-Total";
            // 
            // txt_total
            // 
            this.txt_total.Location = new System.Drawing.Point(1126, 1015);
            this.txt_total.Name = "txt_total";
            this.txt_total.Size = new System.Drawing.Size(413, 31);
            this.txt_total.TabIndex = 16;
            // 
            // txt_SubTotal
            // 
            this.txt_SubTotal.Location = new System.Drawing.Point(1126, 922);
            this.txt_SubTotal.Name = "txt_SubTotal";
            this.txt_SubTotal.Size = new System.Drawing.Size(413, 31);
            this.txt_SubTotal.TabIndex = 15;
            // 
            // btn_Add4
            // 
            this.btn_Add4.Location = new System.Drawing.Point(412, 668);
            this.btn_Add4.Name = "btn_Add4";
            this.btn_Add4.Size = new System.Drawing.Size(204, 38);
            this.btn_Add4.TabIndex = 26;
            this.btn_Add4.Text = "ADD TO CART";
            this.btn_Add4.UseVisualStyleBackColor = true;
            this.btn_Add4.Click += new System.EventHandler(this.btn_Add4_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(386, 404);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 25);
            this.label6.TabIndex = 25;
            this.label6.Text = "Item Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(386, 495);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 25);
            this.label5.TabIndex = 24;
            this.label5.Text = "Item Price";
            // 
            // txt_ItemPrice
            // 
            this.txt_ItemPrice.Location = new System.Drawing.Point(529, 489);
            this.txt_ItemPrice.Name = "txt_ItemPrice";
            this.txt_ItemPrice.Size = new System.Drawing.Size(270, 31);
            this.txt_ItemPrice.TabIndex = 23;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(386, 216);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 25);
            this.label1.TabIndex = 22;
            this.label1.Text = "Upload Image";
            // 
            // txt_ItemName
            // 
            this.txt_ItemName.Location = new System.Drawing.Point(529, 404);
            this.txt_ItemName.Name = "txt_ItemName";
            this.txt_ItemName.Size = new System.Drawing.Size(270, 31);
            this.txt_ItemName.TabIndex = 21;
            // 
            // btn_Upload
            // 
            this.btn_Upload.Location = new System.Drawing.Point(596, 209);
            this.btn_Upload.Name = "btn_Upload";
            this.btn_Upload.Size = new System.Drawing.Size(97, 38);
            this.btn_Upload.TabIndex = 20;
            this.btn_Upload.Text = "Upload";
            this.btn_Upload.UseVisualStyleBackColor = true;
            // 
            // Pbox_Other
            // 
            this.Pbox_Other.Location = new System.Drawing.Point(34, 209);
            this.Pbox_Other.Name = "Pbox_Other";
            this.Pbox_Other.Size = new System.Drawing.Size(298, 497);
            this.Pbox_Other.TabIndex = 19;
            this.Pbox_Other.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1725, 1201);
            this.Controls.Add(this.btn_Add4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_ItemPrice);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_ItemName);
            this.Controls.Add(this.btn_Upload);
            this.Controls.Add(this.Pbox_Other);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_total);
            this.Controls.Add(this.txt_SubTotal);
            this.Controls.Add(this.DGV_Others);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Others)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pbox_Other)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGV_Others;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_total;
        private System.Windows.Forms.TextBox txt_SubTotal;
        private System.Windows.Forms.Button btn_Add4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_ItemPrice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_ItemName;
        private System.Windows.Forms.Button btn_Upload;
        private System.Windows.Forms.PictureBox Pbox_Other;
    }
}