﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shop
{
    public partial class Form2 : Form
    {
        private string text1;
        public string Brg { get; private set; }
        public int jml { get; private set; }
        public string Price { get; private set; }

        private DataTable dt;

        public Form2(DataTable dt_strip, string text)
        {
            InitializeComponent();

            DGV_Others.DataSource = dt;

            txt_SubTotal.Text = "";
            txt_total.Text = "";
        }

        public Form2(DataTable dt_strip, string text, string text1) : this(dt_strip, text)
        {
            this.text1 = text1;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btn_Add4_Click(object sender, EventArgs e)
        {
            if (Brg == txt_ItemName.Text)
            {
                jml++;
            }
            else
            {
                Brg = txt_ItemName.Text;
                Price = txt_ItemPrice.Text;
                jml = 1;
            }
        }
        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }
    }
}
