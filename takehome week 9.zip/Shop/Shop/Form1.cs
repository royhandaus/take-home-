﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shop
{
    public partial class Form1 : Form
    {
        DataTable dt_top_wear = new DataTable();
        DataTable dt_buttom_wear = new DataTable();
        DataTable dt_accessories = new DataTable();
        DataTable dt_others = new DataTable();

        DataTable dt_strip = new DataTable();
        public DataTable dt;
        Form2 form2;
        public Form1(Form _form)
        {
            form2 = _form as Form2;
            InitializeComponent();

            dt_top_wear.Columns.Add("name");
            dt_top_wear.Columns.Add("price");
            dt_buttom_wear.Columns.Add("name");
            dt_buttom_wear.Columns.Add("price");
            dt_accessories.Columns.Add("name");
            dt_accessories.Columns.Add("price");
            dt_others.Columns.Add("name");
            dt_others.Columns.Add("price");

            dt_top_wear.Rows.Add("T-Shirt White", "Rp.120.000,00");
            dt_top_wear.Rows.Add("AlRism T-SHirt", "Rp.150.000,00");
            dt_top_wear.Rows.Add("T-SHirt VNeck", "Rp.170.000,00");
            dt_buttom_wear.Rows.Add("Palazzo Pants", "Rp.629.900,00");
            dt_buttom_wear.Rows.Add("Flare Pants", "Rp.1.590.000,00");
            dt_buttom_wear.Rows.Add("Skinny Jeans", "Rp.699.000,00");
            dt_accessories.Rows.Add("Kalung Salib", "Rp.300.000,00");
            dt_accessories.Rows.Add("Tommy Hilfiger", "Rp.712.000,00");
            dt_accessories.Rows.Add("Jam Tangan Rolex", "Rp.90.000.000,00");
            dt_others.Rows.Add(" ", "Rp.300.000,00");
            dt_others.Rows.Add(" ", "Rp.300.000,00");
            dt_others.Rows.Add(" ", "Rp.300.000,00");

            dt_strip.Columns.Add("Item Name");
            dt_strip.Columns.Add("Quantity");
            dt_strip.Columns.Add("Price");
            dt_strip.Columns.Add("Total");

            DGV_Barang.DataSource = dt_strip;

            dt = dt_strip;

        }

        private void TOPWEARToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lb_nama1.Text = dt_top_wear.Rows[0][0].ToString();
            lb_price1.Text = dt_top_wear.Rows[0][1].ToString();
            lb_nama2.Text = dt_top_wear.Rows[1][0].ToString();
            lb_price2.Text = dt_top_wear.Rows[1][1].ToString();
            lb_nama3.Text = dt_top_wear.Rows[2][0].ToString();
            lb_price3.Text = dt_top_wear.Rows[2][1].ToString();

            show_picture();
        }

        private void BUTTOMWEARToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lb_nama1.Text = dt_buttom_wear.Rows[0][0].ToString();
            lb_price1.Text = dt_buttom_wear.Rows[0][1].ToString();
            lb_nama2.Text = dt_buttom_wear.Rows[1][0].ToString();
            lb_price2.Text = dt_buttom_wear.Rows[1][1].ToString();
            lb_nama3.Text = dt_buttom_wear.Rows[2][0].ToString();
            lb_price3.Text = dt_buttom_wear.Rows[2][1].ToString();

            show_picture();
        }

        private void ACCESSORIESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lb_nama1.Text = dt_accessories.Rows[0][0].ToString();
            lb_price1.Text = dt_accessories.Rows[0][1].ToString();
            lb_nama2.Text = dt_accessories.Rows[1][0].ToString();
            lb_price2.Text = dt_accessories.Rows[1][1].ToString();
            lb_nama3.Text = dt_accessories.Rows[2][0].ToString();
            lb_price3.Text = dt_accessories.Rows[2][1].ToString();

            show_picture();
        }

        private void OTHERSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PBox_1.Visible = false;
            PBox_2.Visible = false;
            Pbox_3.Visible = false;

            lb_nama1.Visible = false;
            lb_nama2.Visible = false;
            lb_nama3.Visible = false;

            lb_price1.Visible = false;
            lb_price2.Visible = false;
            lb_price3.Visible = false;
            form2 = new Form2(dt_strip, txt_SubTotal.Text, txt_Total.Text);
            form2.FormClosed += Form_FormClosed;
            form2.ShowDialog();
        }

        private void Form_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (form2.Brg == null)
            {

            }
            else
            {
                string itemName = form2.Brg;
                string itemPrice = form2.Price;
                int quantity = form2.jml;

                decimal price = decimal.Parse(itemPrice.Replace("Rp.", "").Replace(".", "").Replace(",", ""));
                decimal total = price * quantity;

                bool itemExists = false;

                for (int i = 0; i < dt_strip.Rows.Count; i++)
                {
                    DataRow row = dt_strip.Rows[i];

                    if (row["Item Name"].ToString() == itemName)
                    {
                        int existingQuantity = int.Parse(row["Quantity"].ToString());
                        row["Quantity"] = existingQuantity + quantity;

                        decimal existingPrice = decimal.Parse(row["Price"].ToString().Replace("Rp.", "").Replace(".", ""));
                        decimal newTotal = existingPrice * (existingQuantity + quantity);
                        row["Total"] = string.Format("Rp.{0:#,##0.00}", newTotal);

                        itemExists = true;
                        subtotal();
                        break;
                    }
                }

                if (!itemExists)
                {
                    dt_strip.Rows.Add(itemName, quantity, string.Format("Rp.{0:#,##0.00}", price), string.Format("Rp.{0:#,##0.00}", total));
                }
            }
        }

        private void show_picture()
        {
            PBox_1.Visible = true;
            PBox_2.Visible = true;
            Pbox_3.Visible = true;

            lb_nama1.Visible = true;
            lb_nama2.Visible = true;
            lb_nama3.Visible = true;

            lb_price1.Visible = true;
            lb_price2.Visible = true;
            lb_price3.Visible = true;

            btn_Add1.Visible = true;
            btn_Add2.Visible = true;
            btn_Add3.Visible = true;
        }

        private void btn_Add1_Click(object sender, EventArgs e)
        {
            AddItemToStrip(lb_nama1.Text, lb_price1.Text);
            subtotal();
        }

        private void btn_Add2_Click(object sender, EventArgs e)
        {
            AddItemToStrip(lb_nama2.Text, lb_price2.Text);
            subtotal();
        }

        private void btn_Add3_Click(object sender, EventArgs e)
        {
            AddItemToStrip(lb_nama3.Text, lb_price3.Text);
            subtotal();
        }

        private void AddItemToStrip(string itemName, string itemPrice)
        {
            string cleanPrice = itemPrice.Replace("Rp.", "").Replace(",00", "").Replace(".", "");
            int harga = int.Parse(cleanPrice);

            bool itemExists = false;

            foreach (DataRow row in dt_strip.Rows)
            {
                if (row["Item Name"].ToString() == itemName)
                {
                    int quantity = int.Parse(row["Quantity"].ToString()) + 1;
                    row["Quantity"] = quantity;

                    int totalHarga = harga * quantity;
                    string formattedTotal = string.Format("Rp.{0:#,##0.00}", totalHarga);
                    row["Total"] = formattedTotal;

                    itemExists = true;
                    break;
                }
            }

            if (!itemExists)
            {
                dt_strip.Rows.Add(itemName, 1, itemPrice, itemPrice);
            }
        }
        private void subtotal()
        {
            string[] subtotal = new string[dt_strip.Rows.Count];
            for (int i = 0; i < dt_strip.Rows.Count; i++)
            {
                subtotal[i] = dt_strip.Rows[i]["Total"].ToString().Replace("Rp.", "").Replace(".", "").Replace(",00", "");
            }
            int total = 0;
            for (int i = 0; i < dt_strip.Rows.Count; i++)
            {
                total += Convert.ToInt32(subtotal[i].ToString());
            }
            txt_SubTotal.Text = String.Format("Rp.{0:#,##0.00}", total);
            Double tax = total + (total / 10);
            txt_Total.Text = String.Format("Rp.{0:#,##0.00}", tax);
        }
        public string tbsubtotal()
        {
            return txt_SubTotal.Text;
        }

        public string tbtotal()
        {
            return txt_Total.Text;
        }

    }
}
