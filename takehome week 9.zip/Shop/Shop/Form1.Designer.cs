﻿namespace Shop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.TOPWEARToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BUTTOMWEARToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ACCESSORIESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OTHERSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DGV_Barang = new System.Windows.Forms.DataGridView();
            this.lb_nama1 = new System.Windows.Forms.Label();
            this.lb_price1 = new System.Windows.Forms.Label();
            this.lb_price2 = new System.Windows.Forms.Label();
            this.lb_nama2 = new System.Windows.Forms.Label();
            this.lb_nama3 = new System.Windows.Forms.Label();
            this.lb_price3 = new System.Windows.Forms.Label();
            this.btn_Add1 = new System.Windows.Forms.Button();
            this.btn_Add2 = new System.Windows.Forms.Button();
            this.btn_Add3 = new System.Windows.Forms.Button();
            this.txt_SubTotal = new System.Windows.Forms.TextBox();
            this.txt_Total = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.PBox_1 = new System.Windows.Forms.PictureBox();
            this.Pbox_3 = new System.Windows.Forms.PictureBox();
            this.PBox_2 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Barang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBox_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pbox_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBox_2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TOPWEARToolStripMenuItem,
            this.BUTTOMWEARToolStripMenuItem,
            this.ACCESSORIESToolStripMenuItem,
            this.OTHERSToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(2009, 40);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // TOPWEARToolStripMenuItem
            // 
            this.TOPWEARToolStripMenuItem.Name = "TOPWEARToolStripMenuItem";
            this.TOPWEARToolStripMenuItem.Size = new System.Drawing.Size(147, 36);
            this.TOPWEARToolStripMenuItem.Text = "TOP WEAR";
            this.TOPWEARToolStripMenuItem.Click += new System.EventHandler(this.TOPWEARToolStripMenuItem_Click);
            // 
            // BUTTOMWEARToolStripMenuItem
            // 
            this.BUTTOMWEARToolStripMenuItem.Name = "BUTTOMWEARToolStripMenuItem";
            this.BUTTOMWEARToolStripMenuItem.Size = new System.Drawing.Size(199, 36);
            this.BUTTOMWEARToolStripMenuItem.Text = "BUTTOM WEAR";
            this.BUTTOMWEARToolStripMenuItem.Click += new System.EventHandler(this.BUTTOMWEARToolStripMenuItem_Click);
            // 
            // ACCESSORIESToolStripMenuItem
            // 
            this.ACCESSORIESToolStripMenuItem.Name = "ACCESSORIESToolStripMenuItem";
            this.ACCESSORIESToolStripMenuItem.Size = new System.Drawing.Size(179, 36);
            this.ACCESSORIESToolStripMenuItem.Text = "ACCESSORIES";
            this.ACCESSORIESToolStripMenuItem.Click += new System.EventHandler(this.ACCESSORIESToolStripMenuItem_Click);
            // 
            // OTHERSToolStripMenuItem
            // 
            this.OTHERSToolStripMenuItem.Name = "OTHERSToolStripMenuItem";
            this.OTHERSToolStripMenuItem.Size = new System.Drawing.Size(120, 36);
            this.OTHERSToolStripMenuItem.Text = "OTHERS";
            this.OTHERSToolStripMenuItem.Click += new System.EventHandler(this.OTHERSToolStripMenuItem_Click);
            // 
            // DGV_Barang
            // 
            this.DGV_Barang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Barang.Location = new System.Drawing.Point(953, 149);
            this.DGV_Barang.Name = "DGV_Barang";
            this.DGV_Barang.RowHeadersWidth = 82;
            this.DGV_Barang.RowTemplate.Height = 33;
            this.DGV_Barang.Size = new System.Drawing.Size(1028, 651);
            this.DGV_Barang.TabIndex = 1;
            // 
            // lb_nama1
            // 
            this.lb_nama1.AutoSize = true;
            this.lb_nama1.Location = new System.Drawing.Point(54, 462);
            this.lb_nama1.Name = "lb_nama1";
            this.lb_nama1.Size = new System.Drawing.Size(68, 25);
            this.lb_nama1.TabIndex = 2;
            this.lb_nama1.Text = "Nama";
            // 
            // lb_price1
            // 
            this.lb_price1.AutoSize = true;
            this.lb_price1.Location = new System.Drawing.Point(54, 521);
            this.lb_price1.Name = "lb_price1";
            this.lb_price1.Size = new System.Drawing.Size(70, 25);
            this.lb_price1.TabIndex = 3;
            this.lb_price1.Text = "Harga";
            // 
            // lb_price2
            // 
            this.lb_price2.AutoSize = true;
            this.lb_price2.Location = new System.Drawing.Point(325, 521);
            this.lb_price2.Name = "lb_price2";
            this.lb_price2.Size = new System.Drawing.Size(70, 25);
            this.lb_price2.TabIndex = 4;
            this.lb_price2.Text = "Harga";
            // 
            // lb_nama2
            // 
            this.lb_nama2.AutoSize = true;
            this.lb_nama2.Location = new System.Drawing.Point(325, 462);
            this.lb_nama2.Name = "lb_nama2";
            this.lb_nama2.Size = new System.Drawing.Size(68, 25);
            this.lb_nama2.TabIndex = 5;
            this.lb_nama2.Text = "Nama";
            // 
            // lb_nama3
            // 
            this.lb_nama3.AutoSize = true;
            this.lb_nama3.Location = new System.Drawing.Point(621, 462);
            this.lb_nama3.Name = "lb_nama3";
            this.lb_nama3.Size = new System.Drawing.Size(68, 25);
            this.lb_nama3.TabIndex = 6;
            this.lb_nama3.Text = "Nama";
            // 
            // lb_price3
            // 
            this.lb_price3.AutoSize = true;
            this.lb_price3.Location = new System.Drawing.Point(621, 521);
            this.lb_price3.Name = "lb_price3";
            this.lb_price3.Size = new System.Drawing.Size(70, 25);
            this.lb_price3.TabIndex = 7;
            this.lb_price3.Text = "Harga";
            // 
            // btn_Add1
            // 
            this.btn_Add1.Location = new System.Drawing.Point(77, 584);
            this.btn_Add1.Name = "btn_Add1";
            this.btn_Add1.Size = new System.Drawing.Size(154, 46);
            this.btn_Add1.TabIndex = 8;
            this.btn_Add1.Text = "Add To Cart";
            this.btn_Add1.UseVisualStyleBackColor = true;
            this.btn_Add1.Click += new System.EventHandler(this.btn_Add1_Click);
            // 
            // btn_Add2
            // 
            this.btn_Add2.Location = new System.Drawing.Point(339, 584);
            this.btn_Add2.Name = "btn_Add2";
            this.btn_Add2.Size = new System.Drawing.Size(148, 46);
            this.btn_Add2.TabIndex = 9;
            this.btn_Add2.Text = "Add To Cart";
            this.btn_Add2.UseVisualStyleBackColor = true;
            this.btn_Add2.Click += new System.EventHandler(this.btn_Add2_Click);
            // 
            // btn_Add3
            // 
            this.btn_Add3.Location = new System.Drawing.Point(635, 584);
            this.btn_Add3.Name = "btn_Add3";
            this.btn_Add3.Size = new System.Drawing.Size(140, 46);
            this.btn_Add3.TabIndex = 10;
            this.btn_Add3.Text = "Add To Cart";
            this.btn_Add3.UseVisualStyleBackColor = true;
            this.btn_Add3.Click += new System.EventHandler(this.btn_Add3_Click);
            // 
            // txt_SubTotal
            // 
            this.txt_SubTotal.Location = new System.Drawing.Point(1317, 885);
            this.txt_SubTotal.Name = "txt_SubTotal";
            this.txt_SubTotal.Size = new System.Drawing.Size(413, 31);
            this.txt_SubTotal.TabIndex = 11;
            // 
            // txt_Total
            // 
            this.txt_Total.Location = new System.Drawing.Point(1317, 978);
            this.txt_Total.Name = "txt_Total";
            this.txt_Total.Size = new System.Drawing.Size(413, 31);
            this.txt_Total.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(1037, 879);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(156, 37);
            this.label7.TabIndex = 13;
            this.label7.Text = "Sub-Total";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1088, 972);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 37);
            this.label8.TabIndex = 14;
            this.label8.Text = "Total";
            // 
            // PBox_1
            // 
            this.PBox_1.Location = new System.Drawing.Point(44, 166);
            this.PBox_1.Name = "PBox_1";
            this.PBox_1.Size = new System.Drawing.Size(204, 272);
            this.PBox_1.TabIndex = 15;
            this.PBox_1.TabStop = false;
            // 
            // Pbox_3
            // 
            this.Pbox_3.Location = new System.Drawing.Point(604, 166);
            this.Pbox_3.Name = "Pbox_3";
            this.Pbox_3.Size = new System.Drawing.Size(204, 272);
            this.Pbox_3.TabIndex = 16;
            this.Pbox_3.TabStop = false;
            // 
            // PBox_2
            // 
            this.PBox_2.Location = new System.Drawing.Point(321, 166);
            this.PBox_2.Name = "PBox_2";
            this.PBox_2.Size = new System.Drawing.Size(204, 272);
            this.PBox_2.TabIndex = 17;
            this.PBox_2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2009, 1152);
            this.Controls.Add(this.PBox_2);
            this.Controls.Add(this.Pbox_3);
            this.Controls.Add(this.PBox_1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_Total);
            this.Controls.Add(this.txt_SubTotal);
            this.Controls.Add(this.btn_Add3);
            this.Controls.Add(this.btn_Add2);
            this.Controls.Add(this.btn_Add1);
            this.Controls.Add(this.lb_price3);
            this.Controls.Add(this.lb_nama3);
            this.Controls.Add(this.lb_nama2);
            this.Controls.Add(this.lb_price2);
            this.Controls.Add(this.lb_price1);
            this.Controls.Add(this.lb_nama1);
            this.Controls.Add(this.DGV_Barang);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Barang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBox_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pbox_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBox_2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem TOPWEARToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem BUTTOMWEARToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ACCESSORIESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OTHERSToolStripMenuItem;
        private System.Windows.Forms.DataGridView DGV_Barang;
        private System.Windows.Forms.Label lb_nama1;
        private System.Windows.Forms.Label lb_price1;
        private System.Windows.Forms.Label lb_price2;
        private System.Windows.Forms.Label lb_nama2;
        private System.Windows.Forms.Label lb_nama3;
        private System.Windows.Forms.Label lb_price3;
        private System.Windows.Forms.Button btn_Add1;
        private System.Windows.Forms.Button btn_Add2;
        private System.Windows.Forms.Button btn_Add3;
        private System.Windows.Forms.TextBox txt_SubTotal;
        private System.Windows.Forms.TextBox txt_Total;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox PBox_1;
        private System.Windows.Forms.PictureBox Pbox_3;
        private System.Windows.Forms.PictureBox PBox_2;
    }
}

