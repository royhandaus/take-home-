﻿namespace punya_royhan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DTP_Match = new System.Windows.Forms.DateTimePicker();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_Add = new System.Windows.Forms.Button();
            this.txt_Minute = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.CBox_Type = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Cbox_Player = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Cbox_Tim = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.DGV_Match = new System.Windows.Forms.DataGridView();
            this.txt_MatchId = new System.Windows.Forms.TextBox();
            this.Cbox_Away = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Cbox_Home = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Match)).BeginInit();
            this.SuspendLayout();
            // 
            // DTP_Match
            // 
            this.DTP_Match.Location = new System.Drawing.Point(632, 140);
            this.DTP_Match.Name = "DTP_Match";
            this.DTP_Match.Size = new System.Drawing.Size(243, 22);
            this.DTP_Match.TabIndex = 43;
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(823, 360);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(85, 31);
            this.btn_Delete.TabIndex = 42;
            this.btn_Delete.Text = "delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(732, 360);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(85, 31);
            this.btn_Add.TabIndex = 41;
            this.btn_Add.Text = "add";
            this.btn_Add.UseVisualStyleBackColor = true;
            // 
            // txt_Minute
            // 
            this.txt_Minute.Location = new System.Drawing.Point(732, 242);
            this.txt_Minute.Name = "txt_Minute";
            this.txt_Minute.Size = new System.Drawing.Size(176, 22);
            this.txt_Minute.TabIndex = 40;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(680, 245);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 16);
            this.label6.TabIndex = 39;
            this.label6.Text = "Minute";
            // 
            // CBox_Type
            // 
            this.CBox_Type.FormattingEnabled = true;
            this.CBox_Type.Location = new System.Drawing.Point(732, 330);
            this.CBox_Type.Name = "CBox_Type";
            this.CBox_Type.Size = new System.Drawing.Size(176, 24);
            this.CBox_Type.TabIndex = 38;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(687, 333);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 16);
            this.label7.TabIndex = 37;
            this.label7.Text = "Type";
            // 
            // Cbox_Player
            // 
            this.Cbox_Player.FormattingEnabled = true;
            this.Cbox_Player.Location = new System.Drawing.Point(732, 300);
            this.Cbox_Player.Name = "Cbox_Player";
            this.Cbox_Player.Size = new System.Drawing.Size(176, 24);
            this.Cbox_Player.TabIndex = 36;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(680, 303);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 16);
            this.label8.TabIndex = 35;
            this.label8.Text = "Player";
            // 
            // Cbox_Tim
            // 
            this.Cbox_Tim.FormattingEnabled = true;
            this.Cbox_Tim.Location = new System.Drawing.Point(732, 270);
            this.Cbox_Tim.Name = "Cbox_Tim";
            this.Cbox_Tim.Size = new System.Drawing.Size(176, 24);
            this.Cbox_Tim.TabIndex = 34;
            this.Cbox_Tim.SelectedIndexChanged += new System.EventHandler(this.Cbox_Tim_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(683, 273);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 16);
            this.label5.TabIndex = 33;
            this.label5.Text = "Team";
            // 
            // DGV_Match
            // 
            this.DGV_Match.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Match.Location = new System.Drawing.Point(82, 227);
            this.DGV_Match.Name = "DGV_Match";
            this.DGV_Match.RowHeadersWidth = 51;
            this.DGV_Match.RowTemplate.Height = 24;
            this.DGV_Match.Size = new System.Drawing.Size(544, 225);
            this.DGV_Match.TabIndex = 32;
            // 
            // txt_MatchId
            // 
            this.txt_MatchId.Location = new System.Drawing.Point(198, 136);
            this.txt_MatchId.Name = "txt_MatchId";
            this.txt_MatchId.Size = new System.Drawing.Size(146, 22);
            this.txt_MatchId.TabIndex = 31;
            // 
            // Cbox_Away
            // 
            this.Cbox_Away.FormattingEnabled = true;
            this.Cbox_Away.Location = new System.Drawing.Point(632, 167);
            this.Cbox_Away.Name = "Cbox_Away";
            this.Cbox_Away.Size = new System.Drawing.Size(146, 24);
            this.Cbox_Away.TabIndex = 30;
            this.Cbox_Away.SelectedIndexChanged += new System.EventHandler(this.Cbox_Away_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(547, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 16);
            this.label3.TabIndex = 29;
            this.label3.Text = "Team Away";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(551, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 16);
            this.label4.TabIndex = 28;
            this.label4.Text = "Match Date";
            // 
            // Cbox_Home
            // 
            this.Cbox_Home.FormattingEnabled = true;
            this.Cbox_Home.Location = new System.Drawing.Point(198, 164);
            this.Cbox_Home.Name = "Cbox_Home";
            this.Cbox_Home.Size = new System.Drawing.Size(146, 24);
            this.Cbox_Home.TabIndex = 27;
            this.Cbox_Home.SelectedIndexChanged += new System.EventHandler(this.Cbox_Home_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(109, 167);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 16);
            this.label2.TabIndex = 26;
            this.label2.Text = "Team Home";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(133, 137);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 16);
            this.label1.TabIndex = 25;
            this.label1.Text = "Match ID";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(453, 486);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 32);
            this.button3.TabIndex = 44;
            this.button3.Text = "Insert";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1016, 592);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.DTP_Match);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.txt_Minute);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.CBox_Type);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Cbox_Player);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Cbox_Tim);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.DGV_Match);
            this.Controls.Add(this.txt_MatchId);
            this.Controls.Add(this.Cbox_Away);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Cbox_Home);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Match)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker DTP_Match;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.TextBox txt_Minute;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox CBox_Type;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox Cbox_Player;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox Cbox_Tim;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView DGV_Match;
        private System.Windows.Forms.TextBox txt_MatchId;
        private System.Windows.Forms.ComboBox Cbox_Away;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox Cbox_Home;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
    }
}

