﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace punya_royhan
{
    public partial class Form1 : Form
    {
        MySqlConnection connect;
        MySqlCommand command;
        MySqlDataAdapter adapter;

        string query = " ";
        string selectedteam;

        DataTable dthome;
        DataTable dtaway;
        DataTable dt_tim;
        DataTable dt_playeradd;
        DataTable dt_match;

        public Form1()
        {
            InitializeComponent();
            dt_match = new DataTable();

            connect = new MySqlConnection("server=localhost;uid=root;pwd=Alifakmal288;database=premier_league");
            connect.Open();

            query = "select team_name,team_id from team order by 1 asc";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            dthome  = new DataTable();
            adapter.Fill(dthome);
            Cbox_Home.DataSource = dthome;
            Cbox_Home.DisplayMember = "team_name";

            query = "select team_name,team_id from team order by 1 asc";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            dtaway = new DataTable();
            adapter.Fill(dtaway);
            Cbox_Away.DataSource = dtaway;
            Cbox_Away.DisplayMember = "team_name";

            Cbox_Home.SelectedIndexChanged += Cbox_Home_SelectedIndexChanged;
            Cbox_Away.SelectedIndexChanged += Cbox_Away_SelectedIndexChanged;
            Cbox_Tim.SelectedIndexChanged += Cbox_Tim_SelectedIndexChanged;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Cbox_Home_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Cbox_Home.Text == Cbox_Away.Text)
            {
                MessageBox.Show("error");
            }
            else
            {
                 
                Cbox_Tim.Items.Clear();
                Cbox_Tim.Items.Add(Cbox_Home.Text);
                Cbox_Tim.Items.Add(Cbox_Away.Text);

                if (dt_match.Rows.Count != 0)
                {
                    query = $"select m.match_id from match m, team t where m.team_home = t.team_id and t.team_id ='{Cbox_Home.SelectedValue}'";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    dt_match = new DataTable();
                    adapter.Fill(dt_match);

                    txt_Minute.Text = dt_match.Rows[0][0].ToString();
                }
            }
        }

        private void Cbox_Away_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Cbox_Home.Text == Cbox_Away.Text)
            {
                MessageBox.Show("error");
            }
            else
            {
                
                Cbox_Tim.Items.Clear();
                Cbox_Tim.Items.Add(Cbox_Home.Text);
                Cbox_Tim.Items.Add(Cbox_Away.Text);

                if (dt_match.Rows.Count != 0)
                {
                    query = $"select m.match_id from match m, team t where m.team_home = t.team_id and t.team_id ='{Cbox_Away.SelectedValue}'";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    dt_match = new DataTable();
                    adapter.Fill(dt_match);

                    txt_Minute.Text = dt_match.Rows[0][0].ToString();
                }

            }

        }

        private void Cbox_Tim_SelectedIndexChanged(object sender, EventArgs e)
        {
            query = $"select player_name,player_id from player where team_name = '{Cbox_Tim.SelectedIndex}'";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);

            dt_playeradd = new DataTable();
            adapter.Fill(dt_playeradd);

            Cbox_Player.DataSource = dt_playeradd;
            Cbox_Player.ValueMember = "player_id";
            Cbox_Player.DisplayMember = "player_name";

        }
    }
}
