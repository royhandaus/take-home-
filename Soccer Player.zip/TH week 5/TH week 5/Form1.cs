﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_week_5
{
    public partial class Form1 : Form
    {
        DataTable dt;

        public Form1()
        {
            InitializeComponent();
            dt = new DataTable();
          
        }

        private void btn_AddTim_Click(object sender, EventArgs e)
        {
            string tim = txt_Tim.Text;
            string Negara = txt_Negara.Text;
            string kota = txt_kota.Text;

            if (tim.Length == 0 || Negara.Length == 0 || kota.Length == 0)
            {
                MessageBox.Show("Please fill all fields to add a team.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (CBox_Tim.Items.Contains(tim))
            {
                MessageBox.Show("Team already exists in the list.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!CBox_Negara.Items.Contains(Negara))
            {
                CBox_Negara.Items.Add(Negara);
            }
            CBox_Tim.Items.Add(tim);
        }

        private void btn_AddPlayer_Click(object sender, EventArgs e)
        {
            string nama = txt_Nama.Text.Trim();
            string Nomor = txt_nomorPemain.Text.Trim();
            string posisi = CBox_Posisi.Text.Trim();

            if (nama.Length == 0 || Nomor.Length == 0 || posisi.Length == 0)
            {
                MessageBox.Show("Please fill all fields to add a player.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; 
            }

            lBox_Pemain.Items.Add(Nomor + " " + nama + " " + posisi);
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            lBox_Pemain.Items.Remove(lBox_Pemain.SelectedItem.ToString());
        }

       

        private void Form1_Load(object sender, EventArgs e)
        {
            dt.Columns.Add("Negara");
            dt.Columns.Add("Team");
            dt.Columns.Add("No");
            dt.Columns.Add("nama");
            dt.Columns.Add("role");

          
            dt.Rows.Add("Spanyol", "Barcelona", "1", "Marc-Andre ter Stegen", "GK");
            dt.Rows.Add("Spanyol", "Barcelona", "2", "Sergi Roberto", "DF");
            dt.Rows.Add("Spanyol", "Barcelona", "3", "Gerard Pique", "DF");
            dt.Rows.Add("Spanyol", "Barcelona", "4", "Ronald Araujo", "DF");
            dt.Rows.Add("Spanyol", "Barcelona", "5", "Sergino Dest", "DF");
            dt.Rows.Add("Spanyol", "Barcelona", "6", "Sergio Busquets", "MF");
            dt.Rows.Add("Spanyol", "Barcelona", "7", "Antoine Griezmann", "FW");
            dt.Rows.Add("Spanyol", "Barcelona", "8", "Miralem Pjanic", "MF");
            dt.Rows.Add("Spanyol", "Barcelona", "9", "Martin Braithwaite", "FW");
            dt.Rows.Add("Spanyol", "Barcelona", "10", "Lionel Messi", "FW");
            dt.Rows.Add("Spanyol", "Barcelona", "11", "Ousmane Dembele", "FW");
            dt.Rows.Add("Spanyol", "Barcelona", "12", "Riqui Puig", "MF");
            dt.Rows.Add("Spanyol", "Barcelona", "13", "Neto", "GK");
            dt.Rows.Add("Spanyol", "Barcelona", "14", "Clement Lenglet", "DF");
            dt.Rows.Add("Spanyol", "Barcelona", "15", "Francisco Trincao", "FW");
            dt.Rows.Add("Spanyol", "Barcelona", "16", "Pedri", "MF");
            dt.Rows.Add("Spanyol", "Barcelona", "17", "Jordi Alba", "DF");
            dt.Rows.Add("Spanyol", "Barcelona", "18", "Matheus Fernandes", "MF");
            dt.Rows.Add("Spanyol", "Barcelona", "19", "Matthijs de Ligt", "DF");
            dt.Rows.Add("Spanyol", "Barcelona", "20", "Sergiño Dest", "DF");

           
            dt.Rows.Add("Spanyol", "Real Madrid", "1", "Thibaut Courtois", "GK");
            dt.Rows.Add("Spanyol", "Real Madrid", "2", "Daniel Carvajal", "DF");
            dt.Rows.Add("Spanyol", "Real Madrid", "3", "David Alaba", "DF");
            dt.Rows.Add("Spanyol", "Real Madrid", "4", "Sergio Ramos", "DF");
            dt.Rows.Add("Spanyol", "Real Madrid", "5", "Raphael Varane", "DF");
            dt.Rows.Add("Spanyol", "Real Madrid", "6", "Casemiro", "MF");
            dt.Rows.Add("Spanyol", "Real Madrid", "7", "Eden Hazard", "FW");
            dt.Rows.Add("Spanyol", "Real Madrid", "8", "Toni Kroos", "MF");
            dt.Rows.Add("Spanyol", "Real Madrid", "9", "Karim Benzema", "FW");
            dt.Rows.Add("Spanyol", "Real Madrid", "10", "Luka Modric", "MF");
            dt.Rows.Add("Spanyol", "Real Madrid", "11", "Marco Asensio", "FW");
            dt.Rows.Add("Spanyol", "Real Madrid", "12", "Marcelo", "DF");
            dt.Rows.Add("Spanyol", "Real Madrid", "13", "Federico Valverde", "MF");
            dt.Rows.Add("Spanyol", "Real Madrid", "14", "Rodrygo", "FW");
            dt.Rows.Add("Spanyol", "Real Madrid", "15", "Vinicius Jr", "FW");
            dt.Rows.Add("Spanyol", "Real Madrid", "16", "Isco", "MF");
            dt.Rows.Add("Spanyol", "Real Madrid", "17", "Nacho", "DF");
            dt.Rows.Add("Spanyol", "Real Madrid", "18", "Lucas Vazquez", "MF");
            dt.Rows.Add("Spanyol", "Real Madrid", "19", "Mariano Diaz", "FW");
            dt.Rows.Add("Spanyol", "Real Madrid", "20", "Eder Militao", "DF");

            
            dt.Rows.Add("Inggris", "Liverpool", "1", "Alisson Becker", "GK");
            dt.Rows.Add("Inggris", "Liverpool", "2", "Trent Alexander-Arnold", "DF");
            dt.Rows.Add("Inggris", "Liverpool", "3", "Fabinho", "MF");
            dt.Rows.Add("Inggris", "Liverpool", "4", "Virgil van Dijk", "DF");
            dt.Rows.Add("Inggris", "Liverpool", "5", "Georginio Wijnaldum", "MF");
            dt.Rows.Add("Inggris", "Liverpool", "6", "Jordan Henderson", "MF");
            dt.Rows.Add("Inggris", "Liverpool", "7", "Mohamed Salah", "FW");
            dt.Rows.Add("Inggris", "Liverpool", "8", "Naby Keita", "MF");
            dt.Rows.Add("Inggris", "Liverpool", "9", "Roberto Firmino", "FW");
            dt.Rows.Add("Inggris", "Liverpool", "10", "Sadio Mane", "FW");
            dt.Rows.Add("Inggris", "Liverpool", "11", "Diogo Jota", "FW");
            dt.Rows.Add("Inggris", "Liverpool", "12", "Joe Gomez", "DF");
            dt.Rows.Add("Inggris", "Liverpool", "13", "Adrian", "GK");
            dt.Rows.Add("Inggris", "Liverpool", "14", "James Milner", "MF");
            dt.Rows.Add("Inggris", "Liverpool", "15", "Alex Oxlade-Chamberlain", "MF");
            dt.Rows.Add("Inggris", "Liverpool", "16", "Xherdan Shaqiri", "MF");
            dt.Rows.Add("Inggris", "Liverpool", "17", "Takumi Minamino", "FW");
            dt.Rows.Add("Inggris", "Liverpool", "18", "Kostas Tsimikas", "DF");
            dt.Rows.Add("Inggris", "Liverpool", "19", "Nat Phillips", "DF");
            dt.Rows.Add("Inggris", "Liverpool", "20", "Curtis Jones", "MF");

      
            dt.Rows.Add("Inggris", "Arsenal", "1", "Bernd Leno", "GK");
            dt.Rows.Add("Inggris", "Arsenal", "2", "Hector Bellerin", "DF");
            dt.Rows.Add("Inggris", "Arsenal", "3", "Kieran Tierney", "DF");
            dt.Rows.Add("Inggris", "Arsenal", "4", "Gabriel Magalhaes", "DF");
            dt.Rows.Add("Inggris", "Arsenal", "5", "Ben White", "DF");
            dt.Rows.Add("Inggris", "Arsenal", "6", "Thomas Partey", "MF");
            dt.Rows.Add("Inggris", "Arsenal", "7", "Bukayo Saka", "MF");
            dt.Rows.Add("Inggris", "Arsenal", "8", "Granit Xhaka", "MF");
            dt.Rows.Add("Inggris", "Arsenal", "9", "Alexandre Lacazette", "FW");
            dt.Rows.Add("Inggris", "Arsenal", "10", "Pierre-Emerick Aubameyang", "FW");
            dt.Rows.Add("Inggris", "Arsenal", "11", "Nicolas Pepe", "FW");
            dt.Rows.Add("Inggris", "Arsenal", "12", "Aaron Ramsdale", "GK");
            dt.Rows.Add("Inggris", "Arsenal", "13", "Rob Holding", "DF");
            dt.Rows.Add("Inggris", "Arsenal", "14", "Ainsley Maitland-Niles", "MF");
            dt.Rows.Add("Inggris", "Arsenal", "15", "Calum Chambers", "DF");
            dt.Rows.Add("Inggris", "Arsenal", "16", "Gabriel Martinelli", "FW");
            dt.Rows.Add("Inggris", "Arsenal", "17", "Mohamed Elneny", "MF");
            dt.Rows.Add("Inggris", "Arsenal", "18", "Sead Kolasinac", "DF");
            dt.Rows.Add("Inggris", "Arsenal", "19", "Eddie Nketiah", "FW");
            dt.Rows.Add("Inggris", "Arsenal", "20", "Nuno Tavares", "DF");

        }

        private void CBox_Negara_SelectionChangeCommitted(object sender, EventArgs e)
        {
            lBox_Pemain.Items.Clear();

            
            string selectedCountry = CBox_Negara.SelectedItem?.ToString();
            string selectedTeam = CBox_Tim.SelectedItem?.ToString();

          
            DataRow[] filteredRows = dt.Select("Negara =" + selectedCountry + "AND Team =" + selectedTeam);

            
            foreach (DataRow row in filteredRows)
            {
                string playerName = row.Field<string>("nama");
                lBox_Pemain.Items.Add(playerName);
            }
        }

        private void CBox_Tim_SelectionChangeCommitted(object sender, EventArgs e)
        {
            lBox_Pemain.Items.Clear();

            
            string selectedCountry = CBox_Negara.SelectedItem?.ToString();
            string selectedTeam = CBox_Tim.SelectedItem?.ToString();

            DataRow[] filteredRows = dt.Select("Negara =" + selectedCountry + "AND Team =" + selectedTeam);

        
            foreach (DataRow row in filteredRows)
            {
                string playerName = row.Field<string>("nama");
                lBox_Pemain.Items.Add(playerName);
            }
        }
    }
}
