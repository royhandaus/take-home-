﻿namespace TH_week_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CBox_Negara = new System.Windows.Forms.ComboBox();
            this.CBox_Tim = new System.Windows.Forms.ComboBox();
            this.CBox_Posisi = new System.Windows.Forms.ComboBox();
            this.txt_kota = new System.Windows.Forms.TextBox();
            this.txt_Tim = new System.Windows.Forms.TextBox();
            this.txt_Negara = new System.Windows.Forms.TextBox();
            this.txt_Nama = new System.Windows.Forms.TextBox();
            this.txt_nomorPemain = new System.Windows.Forms.TextBox();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.btn_AddTim = new System.Windows.Forms.Button();
            this.btn_AddPlayer = new System.Windows.Forms.Button();
            this.lBox_Pemain = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CBox_Negara
            // 
            this.CBox_Negara.FormattingEnabled = true;
            this.CBox_Negara.Location = new System.Drawing.Point(335, 219);
            this.CBox_Negara.Name = "CBox_Negara";
            this.CBox_Negara.Size = new System.Drawing.Size(236, 33);
            this.CBox_Negara.TabIndex = 0;
            this.CBox_Negara.SelectionChangeCommitted += new System.EventHandler(this.CBox_Negara_SelectionChangeCommitted);
            // 
            // CBox_Tim
            // 
            this.CBox_Tim.FormattingEnabled = true;
            this.CBox_Tim.Location = new System.Drawing.Point(335, 342);
            this.CBox_Tim.Name = "CBox_Tim";
            this.CBox_Tim.Size = new System.Drawing.Size(236, 33);
            this.CBox_Tim.TabIndex = 1;
            this.CBox_Tim.SelectionChangeCommitted += new System.EventHandler(this.CBox_Tim_SelectionChangeCommitted);
            // 
            // CBox_Posisi
            // 
            this.CBox_Posisi.FormattingEnabled = true;
            this.CBox_Posisi.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.CBox_Posisi.Location = new System.Drawing.Point(1394, 464);
            this.CBox_Posisi.Name = "CBox_Posisi";
            this.CBox_Posisi.Size = new System.Drawing.Size(211, 33);
            this.CBox_Posisi.TabIndex = 2;
            // 
            // txt_kota
            // 
            this.txt_kota.Location = new System.Drawing.Point(870, 464);
            this.txt_kota.Name = "txt_kota";
            this.txt_kota.Size = new System.Drawing.Size(210, 31);
            this.txt_kota.TabIndex = 3;
            // 
            // txt_Tim
            // 
            this.txt_Tim.Location = new System.Drawing.Point(870, 221);
            this.txt_Tim.Name = "txt_Tim";
            this.txt_Tim.Size = new System.Drawing.Size(210, 31);
            this.txt_Tim.TabIndex = 4;
            // 
            // txt_Negara
            // 
            this.txt_Negara.Location = new System.Drawing.Point(870, 344);
            this.txt_Negara.Name = "txt_Negara";
            this.txt_Negara.Size = new System.Drawing.Size(210, 31);
            this.txt_Negara.TabIndex = 5;
            // 
            // txt_Nama
            // 
            this.txt_Nama.Location = new System.Drawing.Point(1394, 221);
            this.txt_Nama.Name = "txt_Nama";
            this.txt_Nama.Size = new System.Drawing.Size(211, 31);
            this.txt_Nama.TabIndex = 6;
            // 
            // txt_nomorPemain
            // 
            this.txt_nomorPemain.Location = new System.Drawing.Point(1394, 344);
            this.txt_nomorPemain.Name = "txt_nomorPemain";
            this.txt_nomorPemain.Size = new System.Drawing.Size(211, 31);
            this.txt_nomorPemain.TabIndex = 7;
            // 
            // btn_Remove
            // 
            this.btn_Remove.Location = new System.Drawing.Point(81, 812);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(125, 55);
            this.btn_Remove.TabIndex = 8;
            this.btn_Remove.Text = "Remove";
            this.btn_Remove.UseVisualStyleBackColor = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // btn_AddTim
            // 
            this.btn_AddTim.Location = new System.Drawing.Point(922, 567);
            this.btn_AddTim.Name = "btn_AddTim";
            this.btn_AddTim.Size = new System.Drawing.Size(111, 48);
            this.btn_AddTim.TabIndex = 9;
            this.btn_AddTim.Text = "Add";
            this.btn_AddTim.UseVisualStyleBackColor = true;
            this.btn_AddTim.Click += new System.EventHandler(this.btn_AddTim_Click);
            // 
            // btn_AddPlayer
            // 
            this.btn_AddPlayer.Location = new System.Drawing.Point(1461, 568);
            this.btn_AddPlayer.Name = "btn_AddPlayer";
            this.btn_AddPlayer.Size = new System.Drawing.Size(103, 47);
            this.btn_AddPlayer.TabIndex = 10;
            this.btn_AddPlayer.Text = "Add";
            this.btn_AddPlayer.UseVisualStyleBackColor = true;
            this.btn_AddPlayer.Click += new System.EventHandler(this.btn_AddPlayer_Click);
            // 
            // lBox_Pemain
            // 
            this.lBox_Pemain.FormattingEnabled = true;
            this.lBox_Pemain.ItemHeight = 25;
            this.lBox_Pemain.Location = new System.Drawing.Point(81, 454);
            this.lBox_Pemain.Name = "lBox_Pemain";
            this.lBox_Pemain.Size = new System.Drawing.Size(408, 329);
            this.lBox_Pemain.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(33, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 33);
            this.label1.TabIndex = 13;
            this.label1.Text = "Soccer Team List";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(62, 217);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(233, 33);
            this.label2.TabIndex = 14;
            this.label2.Text = "Choose Country:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(89, 342);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(206, 33);
            this.label3.TabIndex = 15;
            this.label3.Text = "Choose Team:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(654, 118);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(188, 33);
            this.label10.TabIndex = 22;
            this.label10.Text = "Adding Team";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(654, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(184, 33);
            this.label4.TabIndex = 23;
            this.label4.Text = "Team Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(640, 342);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(208, 33);
            this.label5.TabIndex = 24;
            this.label5.Text = "Team Country:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(681, 462);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(157, 33);
            this.label6.TabIndex = 25;
            this.label6.Text = "Team City:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(1170, 118);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(196, 33);
            this.label11.TabIndex = 26;
            this.label11.Text = "Adding Player";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1184, 221);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(192, 33);
            this.label8.TabIndex = 27;
            this.label8.Text = "Player Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(1158, 344);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(218, 33);
            this.label7.TabIndex = 28;
            this.label7.Text = "Player Number:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(1170, 464);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(218, 33);
            this.label9.TabIndex = 29;
            this.label9.Text = "Player Position:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2125, 1153);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lBox_Pemain);
            this.Controls.Add(this.btn_AddPlayer);
            this.Controls.Add(this.btn_AddTim);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.txt_nomorPemain);
            this.Controls.Add(this.txt_Nama);
            this.Controls.Add(this.txt_Negara);
            this.Controls.Add(this.txt_Tim);
            this.Controls.Add(this.txt_kota);
            this.Controls.Add(this.CBox_Posisi);
            this.Controls.Add(this.CBox_Tim);
            this.Controls.Add(this.CBox_Negara);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CBox_Negara;
        private System.Windows.Forms.ComboBox CBox_Tim;
        private System.Windows.Forms.ComboBox CBox_Posisi;
        private System.Windows.Forms.TextBox txt_kota;
        private System.Windows.Forms.TextBox txt_Tim;
        private System.Windows.Forms.TextBox txt_Negara;
        private System.Windows.Forms.TextBox txt_Nama;
        private System.Windows.Forms.TextBox txt_nomorPemain;
        private System.Windows.Forms.Button btn_Remove;
        private System.Windows.Forms.Button btn_AddTim;
        private System.Windows.Forms.Button btn_AddPlayer;
        private System.Windows.Forms.ListBox lBox_Pemain;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
    }
}

