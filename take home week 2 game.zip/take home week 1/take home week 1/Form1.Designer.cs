﻿namespace take_home_week_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_Menu = new System.Windows.Forms.Panel();
            this.bt_play = new System.Windows.Forms.Button();
            this.lb_kata5 = new System.Windows.Forms.Label();
            this.lb_kata4 = new System.Windows.Forms.Label();
            this.lb_kata3 = new System.Windows.Forms.Label();
            this.lb_kata2 = new System.Windows.Forms.Label();
            this.lb_kata1 = new System.Windows.Forms.Label();
            this.tB_kata4 = new System.Windows.Forms.TextBox();
            this.tB_kata5 = new System.Windows.Forms.TextBox();
            this.tB_kata3 = new System.Windows.Forms.TextBox();
            this.tB_kata2 = new System.Windows.Forms.TextBox();
            this.tB_kata1 = new System.Windows.Forms.TextBox();
            this.panel_Keyboard = new System.Windows.Forms.Panel();
            this.lb_kataRandom = new System.Windows.Forms.Label();
            this.bt_M = new System.Windows.Forms.Button();
            this.lb_tebak1 = new System.Windows.Forms.Label();
            this.bt_N = new System.Windows.Forms.Button();
            this.lb_tebak2 = new System.Windows.Forms.Label();
            this.lb_tebak5 = new System.Windows.Forms.Label();
            this.lb_tebak3 = new System.Windows.Forms.Label();
            this.lb_tebak4 = new System.Windows.Forms.Label();
            this.bt_B = new System.Windows.Forms.Button();
            this.bt_V = new System.Windows.Forms.Button();
            this.bt_C = new System.Windows.Forms.Button();
            this.bt_X = new System.Windows.Forms.Button();
            this.bt_Z = new System.Windows.Forms.Button();
            this.bt_A = new System.Windows.Forms.Button();
            this.bt_L = new System.Windows.Forms.Button();
            this.bt_K = new System.Windows.Forms.Button();
            this.bt_J = new System.Windows.Forms.Button();
            this.bt_H = new System.Windows.Forms.Button();
            this.bt_G = new System.Windows.Forms.Button();
            this.bt_F = new System.Windows.Forms.Button();
            this.bt_D = new System.Windows.Forms.Button();
            this.bt_S = new System.Windows.Forms.Button();
            this.bt_P = new System.Windows.Forms.Button();
            this.bt_O = new System.Windows.Forms.Button();
            this.bt_I = new System.Windows.Forms.Button();
            this.bt_U = new System.Windows.Forms.Button();
            this.bt_Y = new System.Windows.Forms.Button();
            this.bt_T = new System.Windows.Forms.Button();
            this.bt_R = new System.Windows.Forms.Button();
            this.bt_E = new System.Windows.Forms.Button();
            this.bt_W = new System.Windows.Forms.Button();
            this.bt_Q = new System.Windows.Forms.Button();
            this.panel_Menu.SuspendLayout();
            this.panel_Keyboard.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_Menu
            // 
            this.panel_Menu.Controls.Add(this.bt_play);
            this.panel_Menu.Controls.Add(this.lb_kata5);
            this.panel_Menu.Controls.Add(this.lb_kata4);
            this.panel_Menu.Controls.Add(this.lb_kata3);
            this.panel_Menu.Controls.Add(this.lb_kata2);
            this.panel_Menu.Controls.Add(this.lb_kata1);
            this.panel_Menu.Controls.Add(this.tB_kata4);
            this.panel_Menu.Controls.Add(this.tB_kata5);
            this.panel_Menu.Controls.Add(this.tB_kata3);
            this.panel_Menu.Controls.Add(this.tB_kata2);
            this.panel_Menu.Controls.Add(this.tB_kata1);
            this.panel_Menu.Location = new System.Drawing.Point(568, 23);
            this.panel_Menu.Name = "panel_Menu";
            this.panel_Menu.Size = new System.Drawing.Size(735, 443);
            this.panel_Menu.TabIndex = 0;
            // 
            // bt_play
            // 
            this.bt_play.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_play.Location = new System.Drawing.Point(227, 325);
            this.bt_play.Name = "bt_play";
            this.bt_play.Size = new System.Drawing.Size(118, 94);
            this.bt_play.TabIndex = 10;
            this.bt_play.Text = "PLAY!";
            this.bt_play.UseVisualStyleBackColor = true;
            this.bt_play.Click += new System.EventHandler(this.bt_play_Click);
            // 
            // lb_kata5
            // 
            this.lb_kata5.AutoSize = true;
            this.lb_kata5.Location = new System.Drawing.Point(80, 268);
            this.lb_kata5.Name = "lb_kata5";
            this.lb_kata5.Size = new System.Drawing.Size(77, 25);
            this.lb_kata5.TabIndex = 9;
            this.lb_kata5.Text = "kata 5:";
            // 
            // lb_kata4
            // 
            this.lb_kata4.AutoSize = true;
            this.lb_kata4.Location = new System.Drawing.Point(80, 213);
            this.lb_kata4.Name = "lb_kata4";
            this.lb_kata4.Size = new System.Drawing.Size(77, 25);
            this.lb_kata4.TabIndex = 8;
            this.lb_kata4.Text = "kata 4:";
            // 
            // lb_kata3
            // 
            this.lb_kata3.AutoSize = true;
            this.lb_kata3.Location = new System.Drawing.Point(80, 162);
            this.lb_kata3.Name = "lb_kata3";
            this.lb_kata3.Size = new System.Drawing.Size(77, 25);
            this.lb_kata3.TabIndex = 7;
            this.lb_kata3.Text = "kata 3:";
            // 
            // lb_kata2
            // 
            this.lb_kata2.AutoSize = true;
            this.lb_kata2.Location = new System.Drawing.Point(80, 112);
            this.lb_kata2.Name = "lb_kata2";
            this.lb_kata2.Size = new System.Drawing.Size(77, 25);
            this.lb_kata2.TabIndex = 6;
            this.lb_kata2.Text = "kata 2:";
            // 
            // lb_kata1
            // 
            this.lb_kata1.AutoSize = true;
            this.lb_kata1.Location = new System.Drawing.Point(80, 62);
            this.lb_kata1.Name = "lb_kata1";
            this.lb_kata1.Size = new System.Drawing.Size(77, 25);
            this.lb_kata1.TabIndex = 5;
            this.lb_kata1.Text = "kata 1:";
            // 
            // tB_kata4
            // 
            this.tB_kata4.Location = new System.Drawing.Point(188, 207);
            this.tB_kata4.Name = "tB_kata4";
            this.tB_kata4.Size = new System.Drawing.Size(187, 31);
            this.tB_kata4.TabIndex = 4;
            // 
            // tB_kata5
            // 
            this.tB_kata5.Location = new System.Drawing.Point(188, 262);
            this.tB_kata5.Name = "tB_kata5";
            this.tB_kata5.Size = new System.Drawing.Size(187, 31);
            this.tB_kata5.TabIndex = 3;
            // 
            // tB_kata3
            // 
            this.tB_kata3.Location = new System.Drawing.Point(188, 156);
            this.tB_kata3.Name = "tB_kata3";
            this.tB_kata3.Size = new System.Drawing.Size(187, 31);
            this.tB_kata3.TabIndex = 2;
            // 
            // tB_kata2
            // 
            this.tB_kata2.Location = new System.Drawing.Point(188, 106);
            this.tB_kata2.Name = "tB_kata2";
            this.tB_kata2.Size = new System.Drawing.Size(187, 31);
            this.tB_kata2.TabIndex = 1;
            // 
            // tB_kata1
            // 
            this.tB_kata1.Location = new System.Drawing.Point(188, 56);
            this.tB_kata1.Name = "tB_kata1";
            this.tB_kata1.Size = new System.Drawing.Size(187, 31);
            this.tB_kata1.TabIndex = 0;
            // 
            // panel_Keyboard
            // 
            this.panel_Keyboard.Controls.Add(this.lb_kataRandom);
            this.panel_Keyboard.Controls.Add(this.bt_M);
            this.panel_Keyboard.Controls.Add(this.lb_tebak1);
            this.panel_Keyboard.Controls.Add(this.bt_N);
            this.panel_Keyboard.Controls.Add(this.lb_tebak2);
            this.panel_Keyboard.Controls.Add(this.lb_tebak5);
            this.panel_Keyboard.Controls.Add(this.lb_tebak3);
            this.panel_Keyboard.Controls.Add(this.lb_tebak4);
            this.panel_Keyboard.Controls.Add(this.bt_B);
            this.panel_Keyboard.Controls.Add(this.bt_V);
            this.panel_Keyboard.Controls.Add(this.bt_C);
            this.panel_Keyboard.Controls.Add(this.bt_X);
            this.panel_Keyboard.Controls.Add(this.bt_Z);
            this.panel_Keyboard.Controls.Add(this.bt_A);
            this.panel_Keyboard.Controls.Add(this.bt_L);
            this.panel_Keyboard.Controls.Add(this.bt_K);
            this.panel_Keyboard.Controls.Add(this.bt_J);
            this.panel_Keyboard.Controls.Add(this.bt_H);
            this.panel_Keyboard.Controls.Add(this.bt_G);
            this.panel_Keyboard.Controls.Add(this.bt_F);
            this.panel_Keyboard.Controls.Add(this.bt_D);
            this.panel_Keyboard.Controls.Add(this.bt_S);
            this.panel_Keyboard.Controls.Add(this.bt_P);
            this.panel_Keyboard.Controls.Add(this.bt_O);
            this.panel_Keyboard.Controls.Add(this.bt_I);
            this.panel_Keyboard.Controls.Add(this.bt_U);
            this.panel_Keyboard.Controls.Add(this.bt_Y);
            this.panel_Keyboard.Controls.Add(this.bt_T);
            this.panel_Keyboard.Controls.Add(this.bt_R);
            this.panel_Keyboard.Controls.Add(this.bt_E);
            this.panel_Keyboard.Controls.Add(this.bt_W);
            this.panel_Keyboard.Controls.Add(this.bt_Q);
            this.panel_Keyboard.Location = new System.Drawing.Point(179, 522);
            this.panel_Keyboard.Name = "panel_Keyboard";
            this.panel_Keyboard.Size = new System.Drawing.Size(1586, 609);
            this.panel_Keyboard.TabIndex = 1;
            // 
            // lb_kataRandom
            // 
            this.lb_kataRandom.AutoSize = true;
            this.lb_kataRandom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_kataRandom.Location = new System.Drawing.Point(1147, 97);
            this.lb_kataRandom.Name = "lb_kataRandom";
            this.lb_kataRandom.Size = new System.Drawing.Size(80, 37);
            this.lb_kataRandom.TabIndex = 26;
            this.lb_kataRandom.Text = ".......";
            // 
            // bt_M
            // 
            this.bt_M.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_M.Location = new System.Drawing.Point(1020, 461);
            this.bt_M.Name = "bt_M";
            this.bt_M.Size = new System.Drawing.Size(99, 89);
            this.bt_M.TabIndex = 20;
            this.bt_M.Text = "M";
            this.bt_M.UseVisualStyleBackColor = true;
            // 
            // lb_tebak1
            // 
            this.lb_tebak1.AutoSize = true;
            this.lb_tebak1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tebak1.Location = new System.Drawing.Point(518, 126);
            this.lb_tebak1.Name = "lb_tebak1";
            this.lb_tebak1.Size = new System.Drawing.Size(76, 55);
            this.lb_tebak1.TabIndex = 21;
            this.lb_tebak1.Text = "__";
            // 
            // bt_N
            // 
            this.bt_N.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_N.Location = new System.Drawing.Point(893, 461);
            this.bt_N.Name = "bt_N";
            this.bt_N.Size = new System.Drawing.Size(99, 89);
            this.bt_N.TabIndex = 19;
            this.bt_N.Text = "N";
            this.bt_N.UseVisualStyleBackColor = true;
            // 
            // lb_tebak2
            // 
            this.lb_tebak2.AutoSize = true;
            this.lb_tebak2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tebak2.Location = new System.Drawing.Point(619, 126);
            this.lb_tebak2.Name = "lb_tebak2";
            this.lb_tebak2.Size = new System.Drawing.Size(76, 55);
            this.lb_tebak2.TabIndex = 22;
            this.lb_tebak2.Text = "__";
            // 
            // lb_tebak5
            // 
            this.lb_tebak5.AutoSize = true;
            this.lb_tebak5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tebak5.Location = new System.Drawing.Point(936, 126);
            this.lb_tebak5.Name = "lb_tebak5";
            this.lb_tebak5.Size = new System.Drawing.Size(70, 51);
            this.lb_tebak5.TabIndex = 25;
            this.lb_tebak5.Text = "__";
            // 
            // lb_tebak3
            // 
            this.lb_tebak3.AutoSize = true;
            this.lb_tebak3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tebak3.Location = new System.Drawing.Point(726, 126);
            this.lb_tebak3.Name = "lb_tebak3";
            this.lb_tebak3.Size = new System.Drawing.Size(76, 55);
            this.lb_tebak3.TabIndex = 23;
            this.lb_tebak3.Text = "__";
            // 
            // lb_tebak4
            // 
            this.lb_tebak4.AutoSize = true;
            this.lb_tebak4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tebak4.Location = new System.Drawing.Point(830, 126);
            this.lb_tebak4.Name = "lb_tebak4";
            this.lb_tebak4.Size = new System.Drawing.Size(76, 55);
            this.lb_tebak4.TabIndex = 24;
            this.lb_tebak4.Text = "__";
            // 
            // bt_B
            // 
            this.bt_B.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_B.Location = new System.Drawing.Point(769, 461);
            this.bt_B.Name = "bt_B";
            this.bt_B.Size = new System.Drawing.Size(99, 89);
            this.bt_B.TabIndex = 18;
            this.bt_B.Text = "B";
            this.bt_B.UseVisualStyleBackColor = true;
            // 
            // bt_V
            // 
            this.bt_V.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_V.Location = new System.Drawing.Point(649, 461);
            this.bt_V.Name = "bt_V";
            this.bt_V.Size = new System.Drawing.Size(99, 89);
            this.bt_V.TabIndex = 17;
            this.bt_V.Text = "V";
            this.bt_V.UseVisualStyleBackColor = true;
            // 
            // bt_C
            // 
            this.bt_C.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_C.Location = new System.Drawing.Point(528, 461);
            this.bt_C.Name = "bt_C";
            this.bt_C.Size = new System.Drawing.Size(99, 89);
            this.bt_C.TabIndex = 16;
            this.bt_C.Text = "C";
            this.bt_C.UseVisualStyleBackColor = true;
            // 
            // bt_X
            // 
            this.bt_X.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_X.Location = new System.Drawing.Point(398, 461);
            this.bt_X.Name = "bt_X";
            this.bt_X.Size = new System.Drawing.Size(99, 89);
            this.bt_X.TabIndex = 15;
            this.bt_X.Text = "X";
            this.bt_X.UseVisualStyleBackColor = true;
            // 
            // bt_Z
            // 
            this.bt_Z.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Z.Location = new System.Drawing.Point(279, 461);
            this.bt_Z.Name = "bt_Z";
            this.bt_Z.Size = new System.Drawing.Size(99, 89);
            this.bt_Z.TabIndex = 14;
            this.bt_Z.Text = "Z";
            this.bt_Z.UseVisualStyleBackColor = true;
            // 
            // bt_A
            // 
            this.bt_A.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_A.Location = new System.Drawing.Point(224, 354);
            this.bt_A.Name = "bt_A";
            this.bt_A.Size = new System.Drawing.Size(99, 89);
            this.bt_A.TabIndex = 13;
            this.bt_A.Text = "A";
            this.bt_A.UseVisualStyleBackColor = true;
            // 
            // bt_L
            // 
            this.bt_L.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_L.Location = new System.Drawing.Point(1213, 354);
            this.bt_L.Name = "bt_L";
            this.bt_L.Size = new System.Drawing.Size(99, 89);
            this.bt_L.TabIndex = 12;
            this.bt_L.Text = "L";
            this.bt_L.UseVisualStyleBackColor = true;
            // 
            // bt_K
            // 
            this.bt_K.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_K.Location = new System.Drawing.Point(1088, 354);
            this.bt_K.Name = "bt_K";
            this.bt_K.Size = new System.Drawing.Size(99, 89);
            this.bt_K.TabIndex = 11;
            this.bt_K.Text = "K";
            this.bt_K.UseVisualStyleBackColor = true;
            // 
            // bt_J
            // 
            this.bt_J.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_J.Location = new System.Drawing.Point(963, 354);
            this.bt_J.Name = "bt_J";
            this.bt_J.Size = new System.Drawing.Size(99, 89);
            this.bt_J.TabIndex = 2;
            this.bt_J.Text = "J";
            this.bt_J.UseVisualStyleBackColor = true;
            // 
            // bt_H
            // 
            this.bt_H.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_H.Location = new System.Drawing.Point(840, 354);
            this.bt_H.Name = "bt_H";
            this.bt_H.Size = new System.Drawing.Size(99, 89);
            this.bt_H.TabIndex = 2;
            this.bt_H.Text = "H";
            this.bt_H.UseVisualStyleBackColor = true;
            // 
            // bt_G
            // 
            this.bt_G.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_G.Location = new System.Drawing.Point(715, 354);
            this.bt_G.Name = "bt_G";
            this.bt_G.Size = new System.Drawing.Size(99, 89);
            this.bt_G.TabIndex = 10;
            this.bt_G.Text = "G";
            this.bt_G.UseVisualStyleBackColor = true;
            // 
            // bt_F
            // 
            this.bt_F.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_F.Location = new System.Drawing.Point(596, 354);
            this.bt_F.Name = "bt_F";
            this.bt_F.Size = new System.Drawing.Size(99, 89);
            this.bt_F.TabIndex = 2;
            this.bt_F.Text = "F";
            this.bt_F.UseVisualStyleBackColor = true;
            // 
            // bt_D
            // 
            this.bt_D.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_D.Location = new System.Drawing.Point(468, 354);
            this.bt_D.Name = "bt_D";
            this.bt_D.Size = new System.Drawing.Size(99, 89);
            this.bt_D.TabIndex = 2;
            this.bt_D.Text = "D";
            this.bt_D.UseVisualStyleBackColor = true;
            // 
            // bt_S
            // 
            this.bt_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_S.Location = new System.Drawing.Point(348, 354);
            this.bt_S.Name = "bt_S";
            this.bt_S.Size = new System.Drawing.Size(99, 89);
            this.bt_S.TabIndex = 2;
            this.bt_S.Text = "S";
            this.bt_S.UseVisualStyleBackColor = true;
            // 
            // bt_P
            // 
            this.bt_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_P.Location = new System.Drawing.Point(1312, 244);
            this.bt_P.Name = "bt_P";
            this.bt_P.Size = new System.Drawing.Size(99, 89);
            this.bt_P.TabIndex = 9;
            this.bt_P.Text = "P";
            this.bt_P.UseVisualStyleBackColor = true;
            // 
            // bt_O
            // 
            this.bt_O.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_O.Location = new System.Drawing.Point(1194, 244);
            this.bt_O.Name = "bt_O";
            this.bt_O.Size = new System.Drawing.Size(99, 89);
            this.bt_O.TabIndex = 8;
            this.bt_O.Text = "O";
            this.bt_O.UseVisualStyleBackColor = true;
            // 
            // bt_I
            // 
            this.bt_I.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_I.Location = new System.Drawing.Point(1072, 244);
            this.bt_I.Name = "bt_I";
            this.bt_I.Size = new System.Drawing.Size(99, 89);
            this.bt_I.TabIndex = 7;
            this.bt_I.Text = "I";
            this.bt_I.UseVisualStyleBackColor = true;
            // 
            // bt_U
            // 
            this.bt_U.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_U.Location = new System.Drawing.Point(945, 244);
            this.bt_U.Name = "bt_U";
            this.bt_U.Size = new System.Drawing.Size(99, 89);
            this.bt_U.TabIndex = 6;
            this.bt_U.Text = "U";
            this.bt_U.UseVisualStyleBackColor = true;
            // 
            // bt_Y
            // 
            this.bt_Y.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Y.Location = new System.Drawing.Point(822, 244);
            this.bt_Y.Name = "bt_Y";
            this.bt_Y.Size = new System.Drawing.Size(99, 89);
            this.bt_Y.TabIndex = 5;
            this.bt_Y.Text = "Y";
            this.bt_Y.UseVisualStyleBackColor = true;
            // 
            // bt_T
            // 
            this.bt_T.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_T.Location = new System.Drawing.Point(688, 244);
            this.bt_T.Name = "bt_T";
            this.bt_T.Size = new System.Drawing.Size(99, 89);
            this.bt_T.TabIndex = 4;
            this.bt_T.Text = "T";
            this.bt_T.UseVisualStyleBackColor = true;
            // 
            // bt_R
            // 
            this.bt_R.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_R.Location = new System.Drawing.Point(563, 244);
            this.bt_R.Name = "bt_R";
            this.bt_R.Size = new System.Drawing.Size(99, 89);
            this.bt_R.TabIndex = 3;
            this.bt_R.Text = "R";
            this.bt_R.UseVisualStyleBackColor = true;
            // 
            // bt_E
            // 
            this.bt_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_E.Location = new System.Drawing.Point(434, 244);
            this.bt_E.Name = "bt_E";
            this.bt_E.Size = new System.Drawing.Size(99, 89);
            this.bt_E.TabIndex = 2;
            this.bt_E.Text = "E";
            this.bt_E.UseVisualStyleBackColor = true;
            // 
            // bt_W
            // 
            this.bt_W.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_W.Location = new System.Drawing.Point(310, 244);
            this.bt_W.Name = "bt_W";
            this.bt_W.Size = new System.Drawing.Size(99, 89);
            this.bt_W.TabIndex = 1;
            this.bt_W.Text = "W";
            this.bt_W.UseVisualStyleBackColor = true;
            // 
            // bt_Q
            // 
            this.bt_Q.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Q.Location = new System.Drawing.Point(182, 244);
            this.bt_Q.Name = "bt_Q";
            this.bt_Q.Size = new System.Drawing.Size(99, 89);
            this.bt_Q.TabIndex = 0;
            this.bt_Q.Text = "Q";
            this.bt_Q.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1854, 1159);
            this.Controls.Add(this.panel_Keyboard);
            this.Controls.Add(this.panel_Menu);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_Menu.ResumeLayout(false);
            this.panel_Menu.PerformLayout();
            this.panel_Keyboard.ResumeLayout(false);
            this.panel_Keyboard.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Menu;
        private System.Windows.Forms.TextBox tB_kata4;
        private System.Windows.Forms.TextBox tB_kata5;
        private System.Windows.Forms.TextBox tB_kata3;
        private System.Windows.Forms.TextBox tB_kata2;
        private System.Windows.Forms.TextBox tB_kata1;
        private System.Windows.Forms.Label lb_kata5;
        private System.Windows.Forms.Label lb_kata4;
        private System.Windows.Forms.Label lb_kata3;
        private System.Windows.Forms.Label lb_kata2;
        private System.Windows.Forms.Label lb_kata1;
        private System.Windows.Forms.Button bt_play;
        private System.Windows.Forms.Panel panel_Keyboard;
        private System.Windows.Forms.Button bt_E;
        private System.Windows.Forms.Button bt_W;
        private System.Windows.Forms.Button bt_Q;
        private System.Windows.Forms.Button bt_G;
        private System.Windows.Forms.Button bt_F;
        private System.Windows.Forms.Button bt_D;
        private System.Windows.Forms.Button bt_S;
        private System.Windows.Forms.Button bt_P;
        private System.Windows.Forms.Button bt_O;
        private System.Windows.Forms.Button bt_I;
        private System.Windows.Forms.Button bt_U;
        private System.Windows.Forms.Button bt_Y;
        private System.Windows.Forms.Button bt_T;
        private System.Windows.Forms.Button bt_R;
        private System.Windows.Forms.Button bt_H;
        private System.Windows.Forms.Button bt_A;
        private System.Windows.Forms.Button bt_L;
        private System.Windows.Forms.Button bt_K;
        private System.Windows.Forms.Button bt_J;
        private System.Windows.Forms.Button bt_M;
        private System.Windows.Forms.Button bt_N;
        private System.Windows.Forms.Button bt_B;
        private System.Windows.Forms.Button bt_V;
        private System.Windows.Forms.Button bt_C;
        private System.Windows.Forms.Button bt_X;
        private System.Windows.Forms.Button bt_Z;
        private System.Windows.Forms.Label lb_kataRandom;
        private System.Windows.Forms.Label lb_tebak1;
        private System.Windows.Forms.Label lb_tebak2;
        private System.Windows.Forms.Label lb_tebak5;
        private System.Windows.Forms.Label lb_tebak3;
        private System.Windows.Forms.Label lb_tebak4;
    }
}

