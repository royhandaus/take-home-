﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace take_home_week_1
{
    public partial class Form1 : Form
    {

        private List<string> huruf = new List<string>() { "", "", "", "", "" };
        private int IndexWin = 0;
        private string huruf_dipencet = "";
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            panel_Keyboard.Visible = false;

            foreach (Control control in panel_Keyboard.Controls)
            {
                if (control is Button)
                {
                    ((Button)control).Click += HurufButton_Click;
                } 
            }

        }
        private void bt_play_Click(object sender, EventArgs e)
        {
            int kata1 = tB_kata1.Text.Length;
            int kata2 = tB_kata2.Text.Length;
            int kata3 = tB_kata3.Text.Length;
            int kata4 = tB_kata4.Text.Length;
            int kata5 = tB_kata5.Text.Length;

            

            if (kata1 == 5 && kata2 == 5 && kata3 == 5 && kata4 == 5 && kata5 == 5 &&
                tB_kata1.Text != tB_kata2.Text && tB_kata1.Text != tB_kata3.Text && tB_kata1.Text != tB_kata4.Text && tB_kata1.Text != tB_kata5.Text &&
                tB_kata2.Text != tB_kata3.Text && tB_kata2.Text != tB_kata4.Text && tB_kata2.Text != tB_kata5.Text &&
                tB_kata3.Text != tB_kata4.Text && tB_kata3.Text != tB_kata5.Text &&
                tB_kata4.Text != tB_kata5.Text)
            {
                MessageBox.Show("Lets Go!!!");

                
                panel_Keyboard.Visible = true;
                panel_Menu.Visible = false;

                Random rnd = new Random();
                int angkaRnd = rnd.Next(1, 6);
                string acak = " ";
                if (angkaRnd == 1)
                {
                    acak = tB_kata1.Text;
                }
                else if (angkaRnd == 2)
                {
                    acak = tB_kata2.Text;
                }
                else if (angkaRnd == 3)
                {
                    acak = tB_kata3.Text;
                }
                else if (angkaRnd == 4)
                {
                    acak = tB_kata4.Text;
                }
                else if (angkaRnd == 5)
                {
                    acak = tB_kata5.Text;
                }

                lb_kataRandom.Text = acak;

                char[] hurufArray = acak.ToCharArray();
                for (int i = 0; i < hurufArray.Length && i < huruf.Count; i++)
                {
                    huruf[i] = hurufArray[i].ToString();
                }
            }
            else
            {
                MessageBox.Show("salah, Cek lagi");
            }
        }
        private void RubahLabelPerHuruf()
        {
            if (huruf_dipencet == huruf[0])
            {
                lb_tebak1.Text = huruf_dipencet;
                IndexWin++;
            }
            if (huruf_dipencet == huruf[1])
            {
                lb_tebak2.Text = huruf_dipencet;
                IndexWin++;
            }
            if (huruf_dipencet == huruf[2])
            {
                lb_tebak3.Text = huruf_dipencet;
                IndexWin++;
            }
            if (huruf_dipencet == huruf[3])
            {
                lb_tebak4.Text = huruf_dipencet;
                IndexWin++;
            }
            if (huruf_dipencet == huruf[4])
            {
                lb_tebak5.Text = huruf_dipencet;
                IndexWin++;
            }
            if (IndexWin == 5)
            {
                MessageBox.Show("Menang!");
            }
        }
        private void HurufButton_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null)
            {
                huruf_dipencet = btn.Text.ToLower();
                RubahLabelPerHuruf();
            }
        }
    }
}
